(function(){
  var cs = new CSInterface();
  var currentDir = 'in';
  var selectedCurve = [0.25, 0.10, 0.25, 1.00];
  var canvas = document.getElementById('curveCanvas');
  var ctx = canvas.getContext('2d');
  var presets = [
    {name:'Flow Auto',v:[0.20,0.00,0.00,1.00]},
    {name:'Smooth',v:[0.25,0.10,0.25,1.00]},
    {name:'S-Curve',v:[0.45,0.00,0.55,1.00]},
    {name:'Whip',v:[0.16,1.00,0.30,1.00]},
    {name:'Bounce',v:[0.34,1.56,0.64,1.00]},
    {name:'Spring',v:[0.68,-0.55,0.27,1.55]},
    {name:'Expo',v:[0.87,0.00,0.13,1.00]},
    {name:'Soft Pop',v:[0.18,0.89,0.32,1.28]},
    {name:'Snap',v:[0.90,0.00,0.10,1.00]},
    {name:'Heavy',v:[0.70,0.00,0.84,0.00]}
  ];
  var effects = [
    {label:'s_shake', key:'s_shake'},
    {label:'s_blurmocurves', key:'s_blurmocurves'},
    {label:'Twixtor Pro', key:'twixtor'},
    {label:'Looks', key:'looks'},
    {label:'BBC Lens Blur', key:'lensblur'},
    {label:'OBS', key:'obs'}
  ];
  var quickTools = [
    ['FRZ','freezeFrame()'],['FIT','fitToComp()'],['ADJ','makeAdjustmentLayer()'],
    ['NUL','makeNull()'],['SOL','makeSolid()'],['CAM','makeCamera()'],
    ['FILL','applyFill()'],['BLUR','applyFastBlur()'],['TINT','applyTint()']
  ];
  function esc(s){ return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }
  function runJSX(code, cb){
    setStatus('Working…');
    cs.evalScript(code, function(result){
      if(result && result !== 'undefined') setStatus(result); else setStatus('Done');
      if(cb) cb(result);
    });
  }
  window.runJSX = runJSX;
  function setStatus(t){ document.getElementById('status').textContent = t || 'Ready'; }
  document.querySelectorAll('.tab').forEach(function(btn){
    btn.addEventListener('click',function(){
      document.querySelectorAll('.tab,.panel').forEach(function(el){ el.classList.remove('active'); });
      btn.classList.add('active'); document.getElementById(btn.dataset.tab).classList.add('active');
      drawCurve();
    });
  });
  document.querySelectorAll('.pill').forEach(function(btn){
    btn.addEventListener('click',function(){
      document.querySelectorAll('.pill').forEach(function(el){ el.classList.remove('active'); });
      btn.classList.add('active'); currentDir = btn.dataset.dir;
    });
  });
  document.getElementById('compactBtn').addEventListener('click',function(){ document.body.classList.toggle('compact'); setTimeout(drawCurve,50); });
  document.getElementById('duration').addEventListener('input',function(){ document.getElementById('durationValue').textContent=this.value+'f'; });
  var effectWrap = document.getElementById('effectButtons');
  effects.forEach(function(f){
    var b = document.createElement('button'); b.className='btn'; b.textContent=f.label;
    b.addEventListener('click',function(){ runJSX("applyNamedEffect('"+esc(f.key)+"','"+currentDir+"',"+Number(document.getElementById('duration').value)+")"); });
    effectWrap.appendChild(b);
  });
  function makePresetButton(target, item, saved){
    var b=document.createElement('button'); b.className='btn'; b.textContent=item.name;
    b.addEventListener('click',function(){
      selectedCurve = item.v.slice();
      document.querySelectorAll('#presetButtons .btn,#savedButtons .btn').forEach(function(el){ el.classList.remove('selected'); });
      b.classList.add('selected'); drawCurve();
    });
    if(saved){
      b.addEventListener('contextmenu',function(e){ e.preventDefault(); removeSaved(item.name); });
      b.title='Right-click to delete';
    }
    target.appendChild(b); return b;
  }
  var presetWrap=document.getElementById('presetButtons');
  presets.forEach(function(p,i){ var b=makePresetButton(presetWrap,p,false); if(i===0)b.classList.add('selected'); });
  function getSaved(){ try{return JSON.parse(localStorage.getItem('ellieCurves')||'[]');}catch(e){return [];} }
  function setSaved(a){ localStorage.setItem('ellieCurves',JSON.stringify(a)); }
  function renderSaved(){
    var wrap=document.getElementById('savedButtons'); wrap.innerHTML='';
    getSaved().forEach(function(p){ makePresetButton(wrap,p,true); });
  }
  function removeSaved(name){ setSaved(getSaved().filter(function(x){return x.name!==name;})); renderSaved(); setStatus('Deleted '+name); }
  document.getElementById('saveCurve').addEventListener('click',function(){
    var name=(document.getElementById('curveName').value||'Custom Curve').trim();
    var a=getSaved().filter(function(x){return x.name!==name;}); a.push({name:name,v:selectedCurve.slice()}); setSaved(a); renderSaved(); setStatus('Saved '+name);
  });
  document.getElementById('applyCurve').addEventListener('click',function(){ runJSX('applyCurveEase(['+selectedCurve.join(',')+'],\''+currentDir+'\')'); });
  var toolWrap=document.getElementById('quickTools');
  quickTools.forEach(function(t){ var b=document.createElement('button'); b.className='btn'; b.textContent=t[0]; b.dataset.jsx=t[1]; toolWrap.appendChild(b); });
  document.querySelectorAll('[data-jsx]').forEach(function(b){ b.addEventListener('click',function(){runJSX(b.dataset.jsx);}); });
  var anchors=[['↖',0,0],['↑',.5,0],['↗',1,0],['←',0,.5],['●',.5,.5],['→',1,.5],['↙',0,1],['↓',.5,1],['↘',1,1]];
  var aw=document.getElementById('anchorGrid');
  anchors.forEach(function(a){ var b=document.createElement('button'); b.className='anchor'; b.textContent=a[0]; b.addEventListener('click',function(){runJSX('setAnchor('+a[1]+','+a[2]+')');}); aw.appendChild(b); });
  function drawCurve(){
    if(!canvas) return;
    var dpr=window.devicePixelRatio||1, rect=canvas.getBoundingClientRect();
    canvas.width=Math.max(120,rect.width*dpr); canvas.height=Math.max(90,rect.height*dpr); ctx.setTransform(dpr,0,0,dpr,0,0);
    var w=rect.width,h=rect.height,p=15; ctx.clearRect(0,0,w,h);
    ctx.strokeStyle='rgba(116,32,53,.55)'; ctx.lineWidth=1;
    for(var i=0;i<5;i++){ var x=p+(w-p*2)*i/4, y=p+(h-p*2)*i/4; ctx.beginPath();ctx.moveTo(x,p);ctx.lineTo(x,h-p);ctx.stroke();ctx.beginPath();ctx.moveTo(p,y);ctx.lineTo(w-p,y);ctx.stroke(); }
    function pt(x,y){ return [p+x*(w-p*2), h-p-y*(h-p*2)]; }
    var p0=pt(0,0), p1=pt(selectedCurve[0],selectedCurve[1]), p2=pt(selectedCurve[2],selectedCurve[3]), p3=pt(1,1);
    ctx.strokeStyle='rgba(226,58,84,.45)'; ctx.beginPath(); ctx.moveTo(p0[0],p0[1]); ctx.lineTo(p1[0],p1[1]); ctx.moveTo(p2[0],p2[1]); ctx.lineTo(p3[0],p3[1]); ctx.stroke();
    ctx.strokeStyle='#ff4a63'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(p0[0],p0[1]); ctx.bezierCurveTo(p1[0],p1[1],p2[0],p2[1],p3[0],p3[1]); ctx.stroke();
    [p1,p2].forEach(function(q){ctx.fillStyle='#f0d7dc';ctx.beginPath();ctx.arc(q[0],q[1],4,0,Math.PI*2);ctx.fill();});
  }
  window.addEventListener('resize',drawCurve); renderSaved(); drawCurve();

  // MoBar launcher — opens MoBar's individual panels via CEP extension API
  var mobarPanels = [
    {label:'Main',    id:'com.mobar.axwt.main'},
    {label:'Layers',  id:'com.mobar.axwt.layers'},
    {label:'Keyframes',id:'com.mobar.axwt.keyframes'},
    {label:'Easing',  id:'com.mobar.axwt.easing'},
    {label:'Comp',    id:'com.mobar.axwt.composition'},
    {label:'Expressions',id:'com.mobar.axwt.expressions'}
  ];
  var mobarWrap = document.getElementById('mobarButtons');
  mobarPanels.forEach(function(panel){
    var b = document.createElement('button');
    b.className = 'btn';
    b.textContent = panel.label;
    b.title = 'Open MoBar — ' + panel.label;
    b.addEventListener('click', function(){
      try {
        cs.requestOpenExtension(panel.id, '');
        setStatus('MoBar ' + panel.label + ' opened');
      } catch(e) {
        setStatus('MoBar not installed');
      }
    });
    mobarWrap.appendChild(b);
  });

  // ── Precomp button: click = all together, alt+click = each separately ──────
  (function(){
    var precompBtn = document.getElementById('precompBtn');
    if(!precompBtn) return;
    precompBtn.addEventListener('click', function(e){
      if(e.altKey){
        runJSX('precomposeEach()');
      } else {
        runJSX('precomposeSelected()');
      }
    });
  })();

  // ── Animation Presets panel ───────────────────────────────────────────────
  (function(){
    var STORAGE_KEY = 'elliePresets_v1';

    function getSavedPresets(){
      try{ return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]'); }
      catch(e){ return []; }
    }
    function setSavedPresets(a){
      localStorage.setItem(STORAGE_KEY, JSON.stringify(a));
    }

    function renderPresetFileButtons(){
      var wrap = document.getElementById('presetFileButtons');
      var hint = document.getElementById('presetHint');
      if(!wrap) return;
      wrap.innerHTML = '';
      var list = getSavedPresets();
      if(list.length === 0){
        if(hint) hint.style.display = '';
        return;
      }
      if(hint) hint.style.display = 'none';
      list.forEach(function(p){
        var b = document.createElement('button');
        b.className = 'btn';
        b.textContent = p.name;
        b.title = p.path + '\nRight-click to remove';
        b.addEventListener('click', function(){
          runJSX("applyPresetFile('" + esc(p.path) + "')");
        });
        b.addEventListener('contextmenu', function(evt){
          evt.preventDefault();
          setSavedPresets(getSavedPresets().filter(function(x){ return x.path !== p.path; }));
          renderPresetFileButtons();
          setStatus('Removed "' + p.name + '"');
        });
        wrap.appendChild(b);
      });
    }

    var importBtn = document.getElementById('importPresetBtn');
    if(importBtn){
      importBtn.addEventListener('click', function(){
        setStatus('Opening preset browser…');
        cs.evalScript('browseForPreset()', function(result){
          if(!result || result === '' || result === 'undefined'){
            setStatus('Ready');
            return;
          }
          if(result.indexOf('\u26a0') === 0){ setStatus(result); return; }
          var path = result.trim();
          if(!path){ setStatus('Ready'); return; }
          // Extract file name without extension (handle both / and \)
          var name = path.replace(/\\/g,'/').split('/').pop().replace(/\.ffx$/i,'');
          var list = getSavedPresets().filter(function(x){ return x.path !== path; });
          list.push({ name: name, path: path });
          setSavedPresets(list);
          renderPresetFileButtons();
          setStatus('Preset "' + name + '" saved — select layers then click to apply');
        });
      });
    }

    var clearBtn = document.getElementById('clearPresetsBtn');
    if(clearBtn){
      clearBtn.addEventListener('click', function(){
        setSavedPresets([]);
        renderPresetFileButtons();
        setStatus('All presets cleared.');
      });
    }

    renderPresetFileButtons();
  })();

})();
