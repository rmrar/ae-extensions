
(function(){
  const KEY = 'ellieToolsLayoutMode';

  function setLayout(mode, save){
    mode = mode || 'full';
    const panel = document.querySelector('.prime-tools');
    if(!panel) return;

    panel.classList.remove('layout-full','layout-compact','layout-grid');
    panel.classList.add('layout-' + mode);

    document.querySelectorAll('.ellie-layout-bar button[data-layout]').forEach(function(btn){
      btn.classList.toggle('is-active', btn.getAttribute('data-layout') === mode);
    });

    if(save !== false){
      try{ localStorage.setItem(KEY, mode); }catch(e){}
    }
  }

  function ensureLayoutButtons(){
    const panel = document.querySelector('.prime-tools');
    if(!panel) return false;

    let bar = panel.querySelector('.ellie-layout-bar');
    if(!bar){
      bar = document.createElement('div');
      bar.className = 'ellie-layout-bar';
      bar.innerHTML =
        '<button type="button" data-layout="full">Full</button>' +
        '<button type="button" data-layout="compact">Compact</button>' +
        '<button type="button" data-layout="grid">Grid</button>';

      const header = panel.querySelector('.header');
      if(header && header.parentNode){
        header.parentNode.insertBefore(bar, header.nextSibling);
      } else {
        panel.insertBefore(bar, panel.firstChild);
      }

      bar.addEventListener('click', function(e){
        const btn = e.target.closest('button[data-layout]');
        if(!btn) return;
        setLayout(btn.getAttribute('data-layout'), true);
      });
    }

    let saved = 'full';
    try{ saved = localStorage.getItem(KEY) || 'full'; }catch(e){}
    if(['full','compact','grid'].indexOf(saved) === -1) saved = 'full';
    setLayout(saved, false);
    return true;
  }

  let tries = 0;
  const timer = setInterval(function(){
    tries++;
    if(ensureLayoutButtons() || tries > 80) clearInterval(timer);
  }, 150);

  window.addEventListener('DOMContentLoaded', ensureLayoutButtons);
  window.addEventListener('load', ensureLayoutButtons);
})();
