/* EllieTools — clean AE JSX bridge. made by rm.rar */
(function(){
  function comp(){
    var c = app.project.activeItem;
    if (!(c && c instanceof CompItem)) throw new Error('Open a comp first.');
    return c;
  }
  function selectedLayers(){
    var c = comp();
    if (!c.selectedLayers || c.selectedLayers.length < 1) throw new Error('Select at least one layer.');
    return c.selectedLayers;
  }
  function selectedProps(){
    var c = comp();
    if (!c.selectedProperties || c.selectedProperties.length < 1) throw new Error('Select keyframed properties first.');
    return c.selectedProperties;
  }
  function addEffectByCandidates(layer, candidates){
    var group = layer.property('ADBE Effect Parade');
    var lastErr = '';
    for (var i=0;i<candidates.length;i++){
      try { return group.addProperty(candidates[i]); } catch(e){ lastErr = e.toString(); }
    }
    throw new Error('Effect not found/installed: ' + candidates[0]);
  }
  function trySet(prop, value){ try { if(prop) prop.setValue(value); } catch(e){} }
  function activeTime(){ return comp().time; }
  function applyNamedEffect(key, dir, frames){
    try{
      app.beginUndoGroup('EllieTools — Apply Effect');
      var layers = selectedLayers();
      var map = {
        's_shake':['S_Shake','s_shake','Sapphire Shake','S_Shake2'],
        's_blurmocurves':['S_BlurMoCurves','s_blurmocurves','Sapphire BlurMoCurves','S_BlurMoCurves2'],
        'twixtor':['Twixtor Pro','RE:Vision Twixtor Pro','Twixtor','TwixtorPro'],
        'looks':['Looks','Magic Bullet Looks','RG Magic Bullet Looks'],
        'lensblur':['BCC Lens Blur','BBC Lens Blur','Boris Continuum Lens Blur','BCC+ Lens Blur'],
        'obs':['OBS','Optical Glow','BCC Optical Stabilizer','S_OpticalGlow']
      };
      if (!map[key]) throw new Error('Unknown effect button: '+key);
      var dur = framesToTime(Number(frames)||12);
      var t0 = activeTime();
      var count = 0;
      for (var i=0;i<layers.length;i++){
        var fx = addEffectByCandidates(layers[i], map[key]);
        count++;
        // Add practical default animation only when a likely opacity/mix/amount property exists.
        var pNames = ['Amount','Mix','Opacity','Blur Amount','Brightness','Glow Brightness','Shake Amount','Scale'];
        for (var n=0;n<pNames.length;n++){
          var p = fx.property(pNames[n]);
          if (p && p.canSetExpression !== undefined){
            try{
              if (String(dir).toLowerCase()==='out') { p.setValueAtTime(t0, p.value); p.setValueAtTime(t0+dur, 0); }
              else { p.setValueAtTime(t0, 0); p.setValueAtTime(t0+dur, p.value); }
              break;
            }catch(e){}
          }
        }
      }
      return 'Applied '+key+' to '+count+' layer(s).';
    }catch(err){ return '⚠ '+err.message; } finally { try{app.endUndoGroup();}catch(e){} }
  }
  function framesToTime(frames){ return Number(frames) / comp().frameRate; }
  function applyCurveEase(vals, dir){
    try{
      app.beginUndoGroup('EllieTools — Apply Curve');
      var props = selectedProps();
      var influenceOut = Math.max(0.1, Math.min(100, Number(vals[0])*100));
      var speedOut = Math.max(0.01, Math.abs(Number(vals[1])*100));
      var influenceIn = Math.max(0.1, Math.min(100, (1-Number(vals[2]))*100));
      var speedIn = Math.max(0.01, Math.abs((1-Number(vals[3]))*100));
      var easeOut = new KeyframeEase(speedOut, influenceOut);
      var easeIn = new KeyframeEase(speedIn, influenceIn);
      var changed = 0;
      for(var i=0;i<props.length;i++){
        var p = props[i];
        if(!p || p.numKeys < 1) continue;
        for(var k=1;k<=p.numKeys;k++){
          if(!p.keySelected(k)) continue;
          setEaseForProperty(p,k,easeIn,easeOut,dir);
          changed++;
        }
      }
      if(changed===0) throw new Error('Select keyframes first.');
      return 'Curve applied to '+changed+' keyframe(s).';
    }catch(err){ return '⚠ '+err.message; } finally { try{app.endUndoGroup();}catch(e){} }
  }
  function setEaseForProperty(p,k,easeIn,easeOut,dir){
    var dims = 1;
    if(p.propertyValueType === PropertyValueType.TwoD || p.propertyValueType === PropertyValueType.TwoD_SPATIAL) dims = 2;
    if(p.propertyValueType === PropertyValueType.ThreeD || p.propertyValueType === PropertyValueType.ThreeD_SPATIAL) dims = 3;
    var ins=[], outs=[];
    for(var i=0;i<dims;i++){ ins.push(easeIn); outs.push(easeOut); }
    var d = String(dir).toLowerCase();
    if(d==='in') p.setTemporalEaseAtKey(k, ins, p.keyOutTemporalEase(k));
    else if(d==='out') p.setTemporalEaseAtKey(k, p.keyInTemporalEase(k), outs);
    else p.setTemporalEaseAtKey(k, ins, outs);
    try { p.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); } catch(e){}
  }
  function centerLayer(){
    try{ app.beginUndoGroup('EllieTools — Center'); var c=comp(), ls=selectedLayers(); for(var i=0;i<ls.length;i++) trySet(ls[i].property('Position'), [c.width/2,c.height/2]); return 'Centered.'; }catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}}
  }
  function fitToComp(){
    try{ app.beginUndoGroup('EllieTools — Fit'); var c=comp(), ls=selectedLayers(); for(var i=0;i<ls.length;i++){ var l=ls[i]; var r=l.sourceRectAtTime(c.time,false); var sx=c.width/Math.max(1,r.width)*100, sy=c.height/Math.max(1,r.height)*100; var s=Math.min(sx,sy); trySet(l.property('Scale'), [s,s]); trySet(l.property('Position'), [c.width/2,c.height/2]); } return 'Fit to comp.'; }catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}}
  }
  function setAnchor(x,y){
    try{ app.beginUndoGroup('EllieTools — Anchor'); var c=comp(), ls=selectedLayers(); for(var i=0;i<ls.length;i++){ var l=ls[i], r=l.sourceRectAtTime(c.time,false); var oldAP=l.property('Anchor Point').value, oldPos=l.property('Position').value; var newAP=[r.left + r.width*x, r.top + r.height*y]; if(oldAP.length===3)newAP.push(oldAP[2]); var dx=newAP[0]-oldAP[0], dy=newAP[1]-oldAP[1]; trySet(l.property('Anchor Point'), newAP); if(oldPos.length===3) trySet(l.property('Position'), [oldPos[0]+dx, oldPos[1]+dy, oldPos[2]]); else trySet(l.property('Position'), [oldPos[0]+dx, oldPos[1]+dy]); } return 'Anchor moved.'; }catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}}
  }
  function freezeFrame(){ try{ app.beginUndoGroup('EllieTools — Freeze'); var ls=selectedLayers(); for(var i=0;i<ls.length;i++) ls[i].timeRemapEnabled=true; app.executeCommand(app.findMenuCommandId('Freeze Frame')); return 'Freeze frame.';}catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}} }
  function makeAdjustmentLayer(){ try{ app.beginUndoGroup('EllieTools — Adjustment'); var c=comp(), l=c.layers.addSolid([1,1,1],'Ellie Adjustment',c.width,c.height,c.pixelAspect,c.duration); l.adjustmentLayer=true; l.startTime=c.time; return 'Adjustment layer made.';}catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}} }
  function makeNull(){ try{ app.beginUndoGroup('EllieTools — Null'); comp().layers.addNull(); return 'Null made.';}catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}} }
  function makeSolid(){ try{ app.beginUndoGroup('EllieTools — Solid'); var c=comp(); c.layers.addSolid([0.07,0.02,0.03],'Ellie Solid',c.width,c.height,c.pixelAspect,c.duration); return 'Solid made.';}catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}} }
  function makeCamera(){ try{ app.beginUndoGroup('EllieTools — Camera'); var c=comp(); c.layers.addCamera('Ellie Camera',[c.width/2,c.height/2]); return 'Camera made.';}catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}} }
  function applyFill(){ return simpleEffect('ADBE Fill','Fill'); }
  function applyFastBlur(){ return simpleEffect('ADBE Fast Blur','Fast Blur'); }
  function applyTint(){ return simpleEffect('ADBE Tint','Tint'); }
  function simpleEffect(match,label){ try{ app.beginUndoGroup('EllieTools — '+label); var ls=selectedLayers(); for(var i=0;i<ls.length;i++) addEffectByCandidates(ls[i],[match,label]); return label+' applied.';}catch(e){return '⚠ '+e.message;} finally{try{app.endUndoGroup();}catch(x){}} }
  function dtFiniteNumber(value){ return typeof value === 'number' && isFinite(value); }
  function dtFrameDuration(c){ var fd=c.frameDuration; if(!dtFiniteNumber(fd)||fd<=0){ var fr=c.frameRate; fd=1/((dtFiniteNumber(fr)&&fr>0)?fr:30); } return fd; }
  function layerTargetSpan(layer,c){
    var fd=dtFrameDuration(c), targetIn=layer.inPoint, targetOut=layer.outPoint, editSpan=targetOut-targetIn, oneFrameCutoff=fd*1.5;
    try{
      if((!dtFiniteNumber(editSpan)||editSpan<=oneFrameCutoff) && layer.source && dtFiniteNumber(layer.source.duration) && layer.source.duration>oneFrameCutoff){
        var stretch=100; try{stretch=Number(layer.stretch);}catch(e1){} if(!dtFiniteNumber(stretch)||stretch===0) stretch=100;
        var sourceDurationInCompTime=layer.source.duration*Math.abs(stretch)/100;
        var fullIn=layer.startTime, fullOut=fullIn+sourceDurationInCompTime;
        if(dtFiniteNumber(fullIn)&&dtFiniteNumber(fullOut)&&(fullOut-fullIn)>oneFrameCutoff){ targetIn=fullIn; targetOut=fullOut; }
      }
    }catch(e2){}
    try{ if(targetIn<0) targetIn=0; if(dtFiniteNumber(c.duration)&&c.duration>0&&targetOut>c.duration) targetOut=c.duration; }catch(e3){}
    if(!dtFiniteNumber(targetIn)) targetIn=layer.inPoint; if(!dtFiniteNumber(targetOut)) targetOut=layer.outPoint;
    if((targetOut-targetIn)<=oneFrameCutoff) targetOut=targetIn+Math.max(fd,oneFrameCutoff);
    return {inPoint:targetIn,outPoint:targetOut};
  }
  function recordMatchesInner(record,inner){ try{ if(record.used) return false; if(record.name!==inner.name) return false; if(record.source&&inner.source&&record.source!==inner.source) return false; return true; }catch(e){ return false; } }
  function findRecordForInner(records,inner,fallbackIndex){ for(var i=0;i<records.length;i++){ if(recordMatchesInner(records[i],inner)){ records[i].used=true; return records[i]; } } if(fallbackIndex>=0&&fallbackIndex<records.length&&!records[fallbackIndex].used){ records[fallbackIndex].used=true; return records[fallbackIndex]; } return null; }
  function precomposeSelected(){
    try{
      app.beginUndoGroup('EllieTools — Precomp');
      var c=comp(), ls=c.selectedLayers;
      if(!ls||ls.length<1) throw new Error('Select layer(s).');
      var fd=dtFrameDuration(c), minIn=null, maxOut=null, ids=[];
      for(var i=0;i<ls.length;i++){
        var l=ls[i], spanInfo=layerTargetSpan(l,c);
        ids.push(l.index);
        if(minIn===null||spanInfo.inPoint<minIn) minIn=spanInfo.inPoint;
        if(maxOut===null||spanInfo.outPoint>maxOut) maxOut=spanInfo.outPoint;
      }
      var span=maxOut-minIn; if(!dtFiniteNumber(span)||span<=fd) span=fd*2;
      var newComp=c.layers.precompose(ids,'Ellie Precomp',true);
      try{ newComp.duration=span; }catch(e1){}
      try{ newComp.workAreaStart=0; newComp.workAreaDuration=span; }catch(e2){}
      // After precompose(moveAllAttributes=true) AE preserves absolute comp-time
      // values inside the new comp. Subtract minIn so everything is 0-based.
      // We read inPoint/outPoint directly from the inner layers (not from pre-
      // capture records) to avoid version-dependent double-shifts.
      try{
        for(var j=1;j<=newComp.numLayers;j++){
          var inner=newComp.layer(j);
          var rawIn, rawOut;
          try{ rawIn=inner.inPoint; }catch(er1){ rawIn=inner.startTime; }
          try{ rawOut=inner.outPoint; }catch(er2){ rawOut=rawIn+fd; }
          try{ inner.startTime=inner.startTime-minIn; }catch(e3){}
          try{ inner.inPoint=Math.max(0,rawIn-minIn); }catch(e4){}
          try{ inner.outPoint=Math.min(span,rawOut-minIn); }catch(e5){}
        }
      }catch(e6){}
      // Reposition the precomp layer in the parent comp.
      try{
        for(var k=1;k<=c.numLayers;k++){
          var parentLayer=c.layer(k);
          if(parentLayer.source===newComp){
            parentLayer.startTime=minIn;
            parentLayer.inPoint=minIn;
            parentLayer.outPoint=maxOut;
            break;
          }
        }
      }catch(e7){}
      return 'Precomp made: '+newComp.name+' ('+Math.round(span*c.frameRate)+' frames).';
    }catch(e){ return '⚠ '+e.message; } finally{ try{app.endUndoGroup();}catch(x){} }
  }

  // Precomp each selected layer into its own separate precomp (alt+click behaviour)
  function precomposeEach(){
    try{
      app.beginUndoGroup('EllieTools — Precomp Each');
      var c=comp(), ls=c.selectedLayers;
      if(!ls||ls.length<1) throw new Error('Select layer(s).');
      var fd=dtFrameDuration(c);
      // Capture info before any precompose call to avoid index drift
      var layers=[];
      for(var i=0;i<ls.length;i++){
        var l=ls[i], s=layerTargetSpan(l,c);
        layers.push({idx:l.index,name:l.name,minIn:s.inPoint,maxOut:s.outPoint});
      }
      // Process highest index first — single-layer precompose doesn't shift other indices,
      // but going descending is safe and explicit.
      layers.sort(function(a,b){return b.idx-a.idx;});
      var count=0;
      for(var j=0;j<layers.length;j++){
        var info=layers[j];
        var minIn=info.minIn, maxOut=info.maxOut;
        var span=maxOut-minIn; if(!dtFiniteNumber(span)||span<=fd) span=fd*2;
        var newComp=c.layers.precompose([info.idx],info.name+' Precomp',true);
        try{ newComp.duration=span; }catch(e1){}
        try{ newComp.workAreaStart=0; newComp.workAreaDuration=span; }catch(e2){}
        try{
          for(var k=1;k<=newComp.numLayers;k++){
            var inner=newComp.layer(k);
            var rawIn,rawOut;
            try{ rawIn=inner.inPoint; }catch(er1){ rawIn=inner.startTime; }
            try{ rawOut=inner.outPoint; }catch(er2){ rawOut=rawIn+fd; }
            try{ inner.startTime=inner.startTime-minIn; }catch(e3){}
            try{ inner.inPoint=Math.max(0,rawIn-minIn); }catch(e4){}
            try{ inner.outPoint=Math.min(span,rawOut-minIn); }catch(e5){}
          }
        }catch(e6){}
        try{
          for(var m=1;m<=c.numLayers;m++){
            var pl=c.layer(m);
            if(pl.source===newComp){ pl.startTime=minIn; pl.inPoint=minIn; pl.outPoint=maxOut; break; }
          }
        }catch(e7){}
        count++;
      }
      return count+' precomp'+(count!==1?'s':'')+' made.';
    }catch(e){ return '⚠ '+e.message; } finally{ try{app.endUndoGroup();}catch(x){} }
  }

  // Open a native file dialog for selecting an .ffx preset and return its path
  function browseForPreset(){
    try{
      var f=File.openDialog('Select an After Effects Preset (.ffx)','After Effects Presets:*.ffx,All Files:*.*');
      if(!f) return '';
      return f.fsName;
    }catch(e){ return '⚠ '+e.message; }
  }

  // Apply an .ffx preset file path to all selected layers
  function applyPresetFile(fsPath){
    try{
      app.beginUndoGroup('EllieTools — Apply Preset');
      var f=new File(fsPath);
      if(!f.exists) throw new Error('Preset file not found: '+fsPath);
      var ls=selectedLayers();
      if(!ls||ls.length<1) throw new Error('Select at least one layer.');
      var applied=0, skipped=[];
      for(var i=0;i<ls.length;i++){
        try{ ls[i].applyPreset(f); applied++; }
        catch(er){ skipped.push(ls[i].name); }
      }
      if(applied===0) throw new Error('Could not apply preset to any layer — make sure the layers support this preset type.');
      var msg='Preset applied to '+applied+' layer'+(applied!==1?'s':'')+'.';
      if(skipped.length) msg+=' (skipped: '+skipped.join(', ')+')';
      return msg;
    }catch(e){ return '⚠ '+e.message; }
    finally{ try{app.endUndoGroup();}catch(x){} }
  }

  function saveFrame(){ try{ app.executeCommand(app.findMenuCommandId('Save Frame As > File...')); return 'Save frame opened.';}catch(e){return '⚠ '+e.message;} }

  // Extended easing function for custom-damon.js panel
  function applyCurveEaseExt(vals, dir){
    try{
      app.beginUndoGroup('EllieTools — Apply Ease');
      var c = comp();
      var props = c.selectedProperties;
      if(!props || props.length < 1) throw new Error('Select keyframed properties first.');
      var influenceOut = Math.max(0.1, Math.min(100, Number(vals[0])*100));
      var speedOut     = Math.max(0.01, Math.abs(Number(vals[1])*100));
      var influenceIn  = Math.max(0.1, Math.min(100, (1-Number(vals[2]))*100));
      var speedIn      = Math.max(0.01, Math.abs((1-Number(vals[3]))*100));
      var easeOut = new KeyframeEase(speedOut, influenceOut);
      var easeIn  = new KeyframeEase(speedIn, influenceIn);
      var changed = 0;
      for(var i=0; i<props.length; i++){
        var p = props[i];
        if(!p || p.numKeys < 1) continue;
        for(var k=1; k<=p.numKeys; k++){
          if(!p.keySelected(k)) continue;
          var dims = 1;
          if(p.propertyValueType===PropertyValueType.TwoD||p.propertyValueType===PropertyValueType.TwoD_SPATIAL) dims=2;
          if(p.propertyValueType===PropertyValueType.ThreeD||p.propertyValueType===PropertyValueType.ThreeD_SPATIAL) dims=3;
          var ins=[],outs=[];
          for(var d=0;d<dims;d++){ins.push(easeIn);outs.push(easeOut);}
          var dStr = String(dir).toLowerCase();
          if(dStr==='in')   p.setTemporalEaseAtKey(k,ins,p.keyOutTemporalEase(k));
          else if(dStr==='out') p.setTemporalEaseAtKey(k,p.keyInTemporalEase(k),outs);
          else p.setTemporalEaseAtKey(k,ins,outs);
          try{p.setInterpolationTypeAtKey(k,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);}catch(e){}
          changed++;
        }
      }
      if(changed===0) throw new Error('Select keyframes first.');
      return 'Ease applied to '+changed+' keyframe(s).';
    }catch(err){return '⚠ '+err.message;} finally{try{app.endUndoGroup();}catch(x){}}
  }

  // Shortcut helpers for custom-damon.js panel
  function padSlot(id){ var n=Number(id); return n<10?'0'+n:String(n); }
  function getAEShortcutsFilePath(){
    var username='user', aeVer='23.0';
    try{username=System.userName;}catch(e){}
    try{var host=CSXSWindowRuntime?CSXSWindowRuntime.getHostEnvironment():null; if(host) aeVer=host.appVersion.split('.')[0]+'.0';}catch(e){}
    var isMac = $.os.toLowerCase().indexOf('mac')!==-1;
    if(isMac) return '/Users/'+username+'/Library/Preferences/Adobe/After Effects/'+aeVer+'/aeks/Custom.txt';
    return 'C:\\Users\\'+username+'\\AppData\\Roaming\\Adobe\\After Effects\\'+aeVer+'\\aeks\\Custom.txt';
  }
  function readFileSafe(path){ try{var f=new File(path);if(!f.exists)return '';f.open('r');var c=f.read();f.close();return c;}catch(e){return '';} }
  function writeFileSafe(path,content){ try{var f=new File(path);f.open('w');f.write(content);f.close();return true;}catch(e){return false;} }
  function setAEShortcutExt(slotId, keys){
    try{
      var path=getAEShortcutsFilePath(), cmd='ExecuteScriptMenuItem'+padSlot(slotId);
      var content=readFileSafe(path);
      content=content.replace(new RegExp('"'+cmd+'"\\s*=\\s*"\\([^"]*\\)"','g'),'');
      var entry='\n\t"'+cmd+'" = "('+keys+')"\n';
      var si=content.indexOf('["CEggApp"]');
      if(si!==-1) content=content.substring(0,si+'["CEggApp"]'.length)+entry+content.substring(si+'["CEggApp"]'.length);
      else content+='\n["CEggApp"]'+entry;
      writeFileSafe(path,content);
      return 'Shortcut set: '+cmd+' → '+keys;
    }catch(e){return '⚠ '+e.message;}
  }
  function clearAEShortcutExt(slotId){
    try{
      var path=getAEShortcutsFilePath(), cmd='ExecuteScriptMenuItem'+padSlot(slotId);
      var content=readFileSafe(path);
      content=content.replace(new RegExp('"'+cmd+'"\\s*=\\s*"\\([^"]*\\)"','g'),'');
      writeFileSafe(path,content);
      return 'Cleared: '+cmd;
    }catch(e){return '⚠ '+e.message;}
  }
  function runScriptSlotExt(slotId){
    try{
      var n=Number(slotId), id=app.findMenuCommandId('Execute Script Menu Item '+n);
      if(id) app.executeCommand(id); else throw new Error('Script slot '+n+' not found.');
      return 'Ran slot '+n;
    }catch(e){return '⚠ '+e.message;}
  }
  // Expose functions for CEP evalScript

  // ── NeuCurve Pro functions ────────────────────────────────────────────────
  // Ported from NeuCurve Pro 2.5.0 by neucurve.panel.v2
  function getSelectedKeyframes() {
      var result = [];
      var comp = app.project.activeItem;
      if (!comp || !(comp instanceof CompItem)) {
          return JSON.stringify({ error: "Tidak ada komposisi aktif." });
      }
      for (var i = 1; i <= comp.numLayers; i++) {
          var layer = comp.layer(i);
          collectSelectedKeyframes(layer, result, layer.name);
      }
      return JSON.stringify(result);
  }
  
  function collectSelectedKeyframes(propGroup, result, layerName) {
      if (!propGroup) return;
      for (var i = 1; i <= propGroup.numProperties; i++) {
          var prop = propGroup.property(i);
          if (prop.propertyType === PropertyType.PROPERTY) {
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (prop.keySelected(k)) {
                      result.push({
                          layer: layerName,
                          property: prop.name,
                          keyIndex: k,
                          time: prop.keyTime(k),
                          value: prop.keyValue(k).toString()
                      });
                  }
              }
          } else if (prop.propertyType === PropertyType.INDEXED_GROUP ||
                     prop.propertyType === PropertyType.NAMED_GROUP) {
              collectSelectedKeyframes(prop, result, layerName);
          }
      }
  }
  
  // ─────────────────────────────────────────────
  // CUBIC BEZIER MATH HELPERS
  // ─────────────────────────────────────────────
  
  /**
   * Evaluasi posisi Y kurva cubic bezier pada parameter t (0-1)
   * Standard cubic bezier: B(t) = (1-t)^3*P0 + 3(1-t)^2*t*P1 + 3(1-t)*t^2*P2 + t^3*P3
   * P0=(0,0), P3=(1,1), P1=(p1x,p1y), P2=(p2x,p2y)
   */
  function bezierY(t, p1x, p1y, p2x, p2y) {
      var mt = 1 - t;
      return mt*mt*mt*0 + 3*mt*mt*t*p1y + 3*mt*t*t*p2y + t*t*t*1;
  }
  
  function bezierX(t, p1x, p1y, p2x, p2y) {
      var mt = 1 - t;
      return mt*mt*mt*0 + 3*mt*mt*t*p1x + 3*mt*t*t*p2x + t*t*t*1;
  }
  
  /**
   * Turunan pertama Y terhadap t
   * dB/dt = 3(1-t)^2*(P1-P0) + 6(1-t)*t*(P2-P1) + 3t^2*(P3-P2)
   */
  function bezierDY(t, p1x, p1y, p2x, p2y) {
      var mt = 1 - t;
      return 3*mt*mt*(p1y - 0) + 6*mt*t*(p2y - p1y) + 3*t*t*(1 - p2y);
  }
  
  function bezierDX(t, p1x, p1y, p2x, p2y) {
      var mt = 1 - t;
      return 3*mt*mt*(p1x - 0) + 6*mt*t*(p2x - p1x) + 3*t*t*(1 - p2x);
  }
  
  /**
   * Turunan kedua Y terhadap t (untuk deteksi titik balik)
   */
  function bezierDDY(t, p1x, p1y, p2x, p2y) {
      return 6*(1-t)*(p2y - 2*p1y + 0) + 6*t*(1 - 2*p2y + p1y);
  }
  
  /**
   * Cari parameter t dari nilai x menggunakan binary search
   */
  function tFromX(x, p1x, p1y, p2x, p2y) {
      var lo = 0, hi = 1, t = x;
      for (var i = 0; i < 20; i++) {
          var bx = bezierX(t, p1x, p1y, p2x, p2y);
          if (Math.abs(bx - x) < 0.00001) break;
          if (bx < x) lo = t; else hi = t;
          t = (lo + hi) / 2;
      }
      return t;
  }
  
  /**
   * Hitung slope dy/dx di titik x (bukan dy/dt)
   * slope = (dy/dt) / (dx/dt)
   */
  function slopeAtX(x, p1x, p1y, p2x, p2y) {
      var t = tFromX(x, p1x, p1y, p2x, p2y);
      var dx = bezierDX(t, p1x, p1y, p2x, p2y);
      var dy = bezierDY(t, p1x, p1y, p2x, p2y);
      if (Math.abs(dx) < 0.0001) return dy > 0 ? 999 : -999;
      return dy / dx;
  }
  
  /**
   * Cari semua titik kritis (puncak/lembah/titik balik) di kurva
   * Titik kritis = titik dimana dy/dt = 0
   * Kembalikan array nilai x dari titik kritis tersebut
   */
  function findCriticalPoints(p1x, p1y, p2x, p2y) {
      var criticals = [];
      var SAMPLES = 500;
      var prevDY = bezierDY(0, p1x, p1y, p2x, p2y);
  
      for (var i = 1; i <= SAMPLES; i++) {
          var t = i / SAMPLES;
          var currDY = bezierDY(t, p1x, p1y, p2x, p2y);
  
          // Deteksi zero crossing (tanda berubah) = titik kritis
          if (prevDY * currDY < 0) {
              // Binary search untuk menemukan t yang tepat
              var lo = (i-1) / SAMPLES;
              var hi = t;
              for (var j = 0; j < 20; j++) {
                  var mid = (lo + hi) / 2;
                  var midDY = bezierDY(mid, p1x, p1y, p2x, p2y);
                  if (Math.abs(midDY) < 0.0001) break;
                  if (prevDY * midDY < 0) hi = mid;
                  else lo = mid;
              }
              var critT = (lo + hi) / 2;
              var critX = bezierX(critT, p1x, p1y, p2x, p2y);
              // Hanya tambahkan kalau tidak terlalu dekat dengan 0 atau 1
              if (critX > 0.02 && critX < 0.98) {
                  criticals.push(critX);
              }
          }
          prevDY = currDY;
      }
      return criticals;
  }
  
  /**
   * Hitung influence (0-99) dari slope di titik x
   * Slope tinggi = kurva cepat = influence kecil
   * Slope rendah = kurva lambat = influence besar
   *
   * Ini adalah konversi slope → influence yang membuat
   * handle di AE Graph Editor sesuai dengan plugin
   */
  function influenceFromSlope(slope, segmentWidth) {
      // slope dalam satuan (nilai/waktu_normalized)
      // segmentWidth = lebar segmen dalam satuan x (0-1)
      // influence = panjang handle / lebar segmen * 100
      //
      // Untuk kurva Bezier, handle length ≈ 1/3 segmen
      // dengan koreksi berdasarkan slope
      var absSlope = Math.abs(slope);
  
      // Konversi slope ke influence
      // slope ≈ 0 (flat) → influence besar (handle panjang)
      // slope ≈ ∞ (vertical) → influence kecil (handle pendek)
      var influence;
      if (absSlope > 100) {
          influence = 1;
      } else if (absSlope < 0.001) {
          influence = 99;
      } else {
          // influence berbanding terbalik dengan slope
          // dikalibrasi agar mirip dengan tampilan Flow
          influence = Math.min(99, Math.max(1, 33.33 / (absSlope * segmentWidth + 0.001) * 0.5));
      }
      return influence;
  }
  
  // ─────────────────────────────────────────────
  // MODEL 1 — CUBIC BEZIER
  // Smart critical-point baking — seperti Flow
  // ─────────────────────────────────────────────
  
  function applyCubicBezier(jsonParams) {
      var p = JSON.parse(jsonParams);
      app.beginUndoGroup("Curve Editor: Apply Cubic Bezier");
      try {
          var comp = app.project.activeItem;
          if (!comp || !(comp instanceof CompItem)) {
              return JSON.stringify({ error: "Tidak ada komposisi aktif." });
          }
  
          var count = 0;
          for (var i = 1; i <= comp.numLayers; i++) {
              var layer = comp.layer(i);
              count += applyBezierSimple(layer, p);
          }
  
          app.endUndoGroup();
          return JSON.stringify({ success: true, keyframesModified: count });
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  /**
   * Mode SIMPLE — kurva normal tanpa overshoot
   * Hanya set temporalEase di keyframe yang ada, tidak tambah keyframe baru
   */
  function applyBezierSimple(propGroup, p) {
      var count = 0;
      if (!propGroup) return count;
  
      for (var i = 1; i <= propGroup.numProperties; i++) {
          var prop = propGroup.property(i);
  
          if (prop.propertyType === PropertyType.PROPERTY && prop.numKeys > 0) {
              // Skip CUSTOM_VALUE (text source, dropdowns) — can't be eased
              var vt = prop.propertyValueType;
              if (vt === PropertyValueType.CUSTOM_VALUE) continue;
  
              var selectedKeys = [];
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (prop.keySelected(k)) selectedKeys.push(k);
              }
              if (selectedKeys.length === 0) continue;
  
              // Batasi nilai X agar tidak devide by zero
              var infX1 = Math.max(0.001, Math.min(0.999, p.p1x));
              var infX2 = Math.max(0.001, Math.min(0.999, 1 - p.p2x));
  
              // Check if this is a Shape/Mask Path — needs special handling
              var isShapeProp = (vt === PropertyValueType.SHAPE);
  
              for (var si = 0; si < selectedKeys.length; si++) {
                  var k = selectedKeys[si];
                  var prevSelected = (k > 1 && prop.keySelected(k - 1));
                  var nextSelected = (k < prop.numKeys && prop.keySelected(k + 1));
  
                  try {
                      prop.setInterpolationTypeAtKey(k,
                          KeyframeInterpolationType.BEZIER,
                          KeyframeInterpolationType.BEZIER);
  
                      var valType = prop.propertyValueType;
                      var vFirst = prop.keyValue(selectedKeys[0]);
                      var dim = (vFirst.length !== undefined) ? vFirst.length : 1;
  
                      var isSpatial = (valType === PropertyValueType.TwoD_SPATIAL || valType === PropertyValueType.ThreeD_SPATIAL);
                      var isColorProp = (valType === PropertyValueType.COLOR);
                      var easeInArray = [];
                      var easeOutArray = [];
  
                      if (isShapeProp || isColorProp) {
                          // Shape Path & Color: influence-only easing (speed=0), 1 dimension
                          // Like Flow — we can't compute speed from Shape values,
                          // but setTemporalEaseAtKey works fine with influence alone.
                          var eInInf = prevSelected ? (infX2 * 100) : 33.33;
                          var eOutInf = nextSelected ? (infX1 * 100) : 33.33;
                          easeInArray.push(new KeyframeEase(0, eInInf));
                          easeOutArray.push(new KeyframeEase(0, eOutInf));
  
                      } else if (isSpatial) {
                          // Spatial property butuh 1 Speed untuk mengontrol kecepatan sepanjang path
                          var speedIn = 0, speedOut = 0;
  
                          if (prevSelected) {
                              var dtIn = prop.keyTime(k) - prop.keyTime(k - 1);
                              var v1 = prop.keyValue(k - 1), v2 = prop.keyValue(k);
                              var dx = v2[0] - v1[0], dy = v2[1] - v1[1], dz = (dim === 3) ? (v2[2] - v1[2]) : 0;
                              var dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
                              if (dtIn > 0) speedIn = ((1 - p.p2y) / infX2) * (dist / dtIn);
                          }
                          if (nextSelected) {
                              var dtOut = prop.keyTime(k + 1) - prop.keyTime(k);
                              var v1 = prop.keyValue(k), v2 = prop.keyValue(k + 1);
                              var dx = v2[0] - v1[0], dy = v2[1] - v1[1], dz = (dim === 3) ? (v2[2] - v1[2]) : 0;
                              var dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
                              if (dtOut > 0) speedOut = (p.p1y / infX1) * (dist / dtOut);
                          }
  
                          var eInInf = prevSelected ? (infX2 * 100) : 33.33;
                          var eOutInf = nextSelected ? (infX1 * 100) : 33.33;
                          easeInArray.push(new KeyframeEase(speedIn, eInInf));
                          easeOutArray.push(new KeyframeEase(speedOut, eOutInf));
  
                      } else {
                          // Multi-dimensional regular (Scale, Rotation, dll) -> hitung per sumbu
                          for (var d = 0; d < dim; d++) {
                              var speedIn = 0, speedOut = 0;
  
                              if (prevSelected) {
                                  var dtIn = prop.keyTime(k) - prop.keyTime(k - 1);
                                  var v1 = prop.keyValue(k - 1), v2 = prop.keyValue(k);
                                  var dv = (dim > 1) ? (v2[d] - v1[d]) : (v2 - v1);
                                  if (dtIn > 0) speedIn = ((1 - p.p2y) / infX2) * (dv / dtIn);
                              }
                              if (nextSelected) {
                                  var dtOut = prop.keyTime(k + 1) - prop.keyTime(k);
                                  var v1 = prop.keyValue(k), v2 = prop.keyValue(k + 1);
                                  var dv = (dim > 1) ? (v2[d] - v1[d]) : (v2 - v1);
                                  if (dtOut > 0) speedOut = (p.p1y / infX1) * (dv / dtOut);
                              }
  
                              var eInInf = prevSelected ? (infX2 * 100) : 33.33;
                              var eOutInf = nextSelected ? (infX1 * 100) : 33.33;
                              easeInArray.push(new KeyframeEase(speedIn, eInInf));
                              easeOutArray.push(new KeyframeEase(speedOut, eOutInf));
                          }
                      }
  
                      prop.setTemporalEaseAtKey(k, easeInArray, easeOutArray);
                      count++;
                  } catch (e) {
                      throw new Error("Error at key " + k + ": " + e.toString());
                  }
              }
  
          } else if (prop.propertyType === PropertyType.INDEXED_GROUP ||
                     prop.propertyType === PropertyType.NAMED_GROUP) {
              count += applyBezierSimple(prop, p);
          }
      }
      return count;
  }
  
  
  function applyBezierSmartBake(propGroup, p) {
      var count = 0;
      if (!propGroup) return count;
  
      // Cari titik kritis sekali saja
      var criticalXs = findCriticalPoints(p.p1x, p.p1y, p.p2x, p.p2y);
  
      for (var i = 1; i <= propGroup.numProperties; i++) {
          var prop = propGroup.property(i);
  
          if (prop.propertyType === PropertyType.PROPERTY && prop.numKeys >= 2) {
              var vt = prop.propertyValueType;
              if (vt === PropertyValueType.CUSTOM_VALUE || vt === PropertyValueType.SHAPE) continue;
  
              var firstKey = -1, lastKey = -1;
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (prop.keySelected(k)) {
                      if (firstKey === -1) firstKey = k;
                      lastKey = k;
                  }
              }
              if (firstKey === -1 || firstKey === lastKey) continue;
  
              var t1       = prop.keyTime(firstKey);
              var t2       = prop.keyTime(lastKey);
              var v1       = prop.keyValue(firstKey);
              var v2       = prop.keyValue(lastKey);
              var duration = t2 - t1;
  
              // Hapus keyframe lama di tengah
              for (var k = lastKey - 1; k > firstKey; k--) {
                  prop.removeKey(k);
              }
  
              // Buat keyframe di setiap titik kritis
              for (var ci = 0; ci < criticalXs.length; ci++) {
                  var cx = criticalXs[ci];
                  var tParam = tFromX(cx, p.p1x, p.p1y, p.p2x, p.p2y);
                  var cy = bezierY(tParam, p.p1x, p.p1y, p.p2x, p.p2y);
  
                  var tTime = t1 + cx * duration;
                  var val;
                  if (v1.length !== undefined) {
                      val = [];
                      for (var d = 0; d < v1.length; d++) {
                          val[d] = v1[d] + (v2[d] - v1[d]) * cy;
                      }
                  } else {
                      val = v1 + (v2 - v1) * cy;
                  }
                  var idx = prop.addKey(tTime);
                  prop.setValueAtKey(idx, val);
                  count++;
              }
  
              // Sekarang set temporalEase untuk semua keyframe
              // Cari ulang index firstKey dan lastKey
              var fIdx = -1, lIdx = -1;
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (Math.abs(prop.keyTime(k) - t1) < 0.0001) fIdx = k;
                  if (Math.abs(prop.keyTime(k) - t2) < 0.0001) lIdx = k;
              }
              if (fIdx === -1 || lIdx === -1) continue;
  
              // Semua keyframe antara fIdx dan lIdx (termasuk kritis)
              var allKeyTimes = [];
              for (var k = fIdx; k <= lIdx; k++) {
                  allKeyTimes.push(prop.keyTime(k));
              }
  
              for (var k = fIdx; k <= lIdx; k++) {
                  var ki = k - fIdx; // index dalam allKeyTimes
                  var xNorm; // posisi x dalam 0-1 (normalized time)
                  if (duration > 0) {
                      xNorm = (prop.keyTime(k) - t1) / duration;
                  } else {
                      xNorm = 0;
                  }
                  xNorm = Math.max(0, Math.min(1, xNorm));
  
                  try {
                      prop.setInterpolationTypeAtKey(k,
                          KeyframeInterpolationType.BEZIER,
                          KeyframeInterpolationType.BEZIER);
  
                      // Hitung slope kurva di titik ini
                      var slope = slopeAtX(xNorm, p.p1x, p.p1y, p.p2x, p.p2y);
  
                      // Hitung lebar segmen kiri dan kanan
                      var segWidthLeft  = (ki > 0) ? (xNorm - (prop.keyTime(fIdx + ki - 1) - t1) / duration) : xNorm;
                      var segWidthRight = (ki < allKeyTimes.length - 1) ? ((prop.keyTime(fIdx + ki + 1) - t1) / duration - xNorm) : (1 - xNorm);
  
                      // Influence untuk ease IN (dari kiri)
                      var inInf;
                      if (k === fIdx) {
                          inInf = 33.33; // keyframe pertama tidak punya ease in
                      } else {
                          // Slope di titik kritis = 0 (puncak/lembah)
                          // → influence besar (handle panjang, transisi halus)
                          var absSlope = Math.abs(slope);
                          if (absSlope < 0.1) {
                              inInf = 99; // flat = handle panjang
                          } else {
                              inInf = Math.max(1, Math.min(99, segWidthLeft * 100 * 0.5));
                          }
                      }
  
                      // Influence untuk ease OUT (ke kanan)
                      var outInf;
                      if (k === lIdx) {
                          outInf = 33.33; // keyframe terakhir tidak punya ease out
                      } else {
                          var absSlope2 = Math.abs(slope);
                          if (absSlope2 < 0.1) {
                              outInf = 99;
                          } else {
                              outInf = Math.max(1, Math.min(99, segWidthRight * 100 * 0.5));
                          }
                      }
  
                      // Keyframe pertama — gunakan p1x langsung
                      if (k === fIdx) {
                          outInf = Math.max(1, Math.min(99, p.p1x * 100));
                      }
                      // Keyframe terakhir — gunakan p2x langsung
                      if (k === lIdx) {
                          inInf = Math.max(1, Math.min(99, (1 - p.p2x) * 100));
                      }
  
                      var easeIn  = new KeyframeEase(0, inInf);
                      var easeOut = new KeyframeEase(0, outInf);
                      prop.setTemporalEaseAtKey(k, [easeIn], [easeOut]);
  
                  } catch (e) {
                      throw new Error("SmartBake err key " + k + ": " + e.toString());
                  }
              }
  
          } else if (prop.propertyType === PropertyType.INDEXED_GROUP ||
                     prop.propertyType === PropertyType.NAMED_GROUP) {
              count += applyBezierSmartBake(prop, p);
          }
      }
      return count;
  }
  
  // ─────────────────────────────────────────────
  // MODEL 2 — ELASTIC / OVERSHOOT
  // ─────────────────────────────────────────────
  
  function applyElastic(jsonParams) {
      var p = JSON.parse(jsonParams);
      app.beginUndoGroup("NeuCurve: Apply Elastic");
      try {
          var count = applyExpressionToSelected(p, "elastic");
          app.endUndoGroup();
          return JSON.stringify({ success: true, keyframesModified: count });
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  // ─────────────────────────────────────────────
  // MODEL 3 — BOUNCE (Physical)
  // ─────────────────────────────────────────────
  
  function applyBounce(jsonParams) {
      var p = JSON.parse(jsonParams);
      app.beginUndoGroup("NeuCurve: Apply Bounce");
      try {
          var count = applyExpressionToSelected(p, "bounce");
          app.endUndoGroup();
          return JSON.stringify({ success: true, keyframesModified: count });
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  // ─────────────────────────────────────────────
  // MODEL 4 — STEPS (Staircase)
  // ─────────────────────────────────────────────
  
  function applySteps(jsonParams) {
      var p = JSON.parse(jsonParams);
      var steps = Math.round(p.count);
      var position = p.position || "end";
      app.beginUndoGroup("Curve Editor: Apply Steps");
      try {
          var comp = app.project.activeItem;
          if (!comp || !(comp instanceof CompItem)) {
              return JSON.stringify({ error: "Tidak ada komposisi aktif." });
          }
          var count = 0;
          for (var i = 1; i <= comp.numLayers; i++) {
              var layer = comp.layer(i);
              count += applyStepsToGroup(layer, steps, position);
          }
          app.endUndoGroup();
          return JSON.stringify({ success: true, keyframesCreated: count });
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  function applyStepsToGroup(propGroup, steps, position) {
      var count = 0;
      if (!propGroup) return count;
      for (var i = 1; i <= propGroup.numProperties; i++) {
          var prop = propGroup.property(i);
          if (prop.propertyType === PropertyType.PROPERTY && prop.numKeys >= 2) {
              var vt = prop.propertyValueType;
              if (vt === PropertyValueType.CUSTOM_VALUE || vt === PropertyValueType.SHAPE) continue;
  
              var firstKey = -1, lastKey = -1;
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (prop.keySelected(k)) {
                      if (firstKey === -1) firstKey = k;
                      lastKey = k;
                  }
              }
              if (firstKey === -1 || firstKey === lastKey) continue;
              var t1 = prop.keyTime(firstKey);
              var t2 = prop.keyTime(lastKey);
              var v1 = prop.keyValue(firstKey);
              var v2 = prop.keyValue(lastKey);
              var duration = t2 - t1;
              for (var k = lastKey - 1; k > firstKey; k--) {
                  prop.removeKey(k);
              }
              prop.setInterpolationTypeAtKey(firstKey,
                  KeyframeInterpolationType.HOLD,
                  KeyframeInterpolationType.HOLD);
              for (var s = 1; s < steps; s++) {
                  var fraction;
                  var valFraction = s / steps;
                  
                  if (position === "start") fraction = s / steps;
                  else if (position === "both") fraction = (s - 0.5) / steps;
                  else fraction = s / steps;
  
                  var t = t1 + fraction * duration;
                  var val;
                  if (v1.length) {
                      val = [];
                      for (var d = 0; d < v1.length; d++) {
                          val[d] = v1[d] + (v2[d] - v1[d]) * valFraction;
                      }
                  } else {
                      val = v1 + (v2 - v1) * valFraction;
                  }
                  var newKeyIdx = prop.addKey(t);
                  prop.setValueAtKey(newKeyIdx, val);
                  prop.setInterpolationTypeAtKey(newKeyIdx,
                      KeyframeInterpolationType.HOLD,
                      KeyframeInterpolationType.HOLD);
                  count++;
              }
          } else if (prop.propertyType === PropertyType.INDEXED_GROUP ||
                     prop.propertyType === PropertyType.NAMED_GROUP) {
              count += applyStepsToGroup(prop, steps, position);
          }
      }
      return count;
  }
  
  // ─────────────────────────────────────────────
  // MODEL 5 — CUSTOM PATH
  // ─────────────────────────────────────────────
  
  function applyCustomPath(jsonParams) {
      var p = JSON.parse(jsonParams);
      var mode = p.mode || "bake";
      app.beginUndoGroup("NeuCurve: Apply Custom Path");
      try {
          if (mode === "bake") {
              var result = bakeCustomPath(p.points);
              app.endUndoGroup();
              return JSON.stringify(result);
          } else {
              var count = applyExpressionToSelected(p, "custom");
              app.endUndoGroup();
              return JSON.stringify({ success: true, keyframesModified: count });
          }
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  function bakeCustomPath(points) {
      var comp = app.project.activeItem;
      if (!comp || !(comp instanceof CompItem)) {
          return { error: "Tidak ada komposisi aktif." };
      }
      var totalCreated = 0;
      for (var i = 1; i <= comp.numLayers; i++) {
          var layer = comp.layer(i);
          totalCreated += bakeToGroup(layer, points);
      }
      return { success: true, keyframesCreated: totalCreated };
  }
  
  function bakeToGroup(propGroup, points) {
      var count = 0;
      if (!propGroup) return count;
      var n = points.length;
  
      for (var i = 1; i <= propGroup.numProperties; i++) {
          var prop = propGroup.property(i);
  
          if (prop.propertyType === PropertyType.PROPERTY && prop.numKeys >= 2) {
              var vt = prop.propertyValueType;
              if (vt === PropertyValueType.CUSTOM_VALUE || vt === PropertyValueType.SHAPE) continue;
  
              var firstKey = -1, lastKey = -1;
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (prop.keySelected(k)) {
                      if (firstKey === -1) firstKey = k;
                      lastKey = k;
                  }
              }
              if (firstKey === -1 || firstKey === lastKey) continue;
  
              var t1       = prop.keyTime(firstKey);
              var t2       = prop.keyTime(lastKey);
              var v1       = prop.keyValue(firstKey);
              var v2       = prop.keyValue(lastKey);
              var duration = t2 - t1;
  
              for (var k = lastKey - 1; k > firstKey; k--) {
                  prop.removeKey(k);
              }
  
              for (var pi = 1; pi < n - 1; pi++) {
                  var pt    = points[pi];
                  var tTime = t1 + pt.x * duration;
                  var val;
                  if (v1.length !== undefined) {
                      val = [];
                      for (var d = 0; d < v1.length; d++) {
                          val[d] = v1[d] + (v2[d] - v1[d]) * pt.y;
                      }
                  } else {
                      val = v1 + (v2 - v1) * pt.y;
                  }
                  var idx = prop.addKey(tTime);
                  prop.setValueAtKey(idx, val);
                  count++;
              }
  
              var fIdx = -1, lIdx = -1;
              for (var k = 1; k <= prop.numKeys; k++) {
                  if (Math.abs(prop.keyTime(k) - t1) < 0.0001) fIdx = k;
                  if (Math.abs(prop.keyTime(k) - t2) < 0.0001) lIdx = k;
              }
              if (fIdx === -1 || lIdx === -1) continue;
  
              for (var k = fIdx; k <= lIdx; k++) {
                  var pi2 = k - fIdx;
                  if (pi2 < 0 || pi2 >= n) continue;
                  var pt2 = points[pi2];
                  try {
                      prop.setInterpolationTypeAtKey(k,
                          KeyframeInterpolationType.BEZIER,
                          KeyframeInterpolationType.BEZIER);
  
                      var outInfluence = 33.33;
                      var outSlopeCurve = 0;
                      if (pi2 < n - 1) {
                          var segDurOut = points[pi2 + 1].x - pt2.x;
                          if (segDurOut > 0.0001) {
                              var dxOut = pt2.cx2 - pt2.x;
                              outInfluence = Math.abs(dxOut) / segDurOut * 100;
                              outInfluence = Math.max(1, Math.min(99, outInfluence));
                              if (Math.abs(dxOut) > 0.0001) outSlopeCurve = (pt2.cy2 - pt2.y) / dxOut;
                          }
                      }
  
                      var inInfluence = 33.33;
                      var inSlopeCurve = 0;
                      if (pi2 > 0) {
                          var segDurIn = pt2.x - points[pi2 - 1].x;
                          if (segDurIn > 0.0001) {
                              var dxIn = pt2.x - pt2.cx1;
                              inInfluence = Math.abs(dxIn) / segDurIn * 100;
                              inInfluence = Math.max(1, Math.min(99, inInfluence));
                              if (Math.abs(dxIn) > 0.0001) inSlopeCurve = (pt2.y - pt2.cy1) / dxIn;
                          }
                      }
  
                      var valType = prop.propertyValueType;
                      var dim = (v1 !== undefined && v1.length !== undefined) ? v1.length : 1;
  
                      var isSpatial = (valType === PropertyValueType.TwoD_SPATIAL || valType === PropertyValueType.ThreeD_SPATIAL);
                      var isColorProp = (valType === PropertyValueType.COLOR);
                      var easeInArray = [];
                      var easeOutArray = [];
  
                      if (isColorProp) {
                          easeInArray.push(new KeyframeEase(0, inInfluence));
                          easeOutArray.push(new KeyframeEase(0, outInfluence));
                      } else if (isSpatial) {
                          var speedIn = 0, speedOut = 0;
                          var distG = 0;
                          if (v1.length) {
                              var dxG = v2[0] - v1[0], dyG = v2[1] - v1[1], dzG = (dim === 3) ? (v2[2] - v1[2]) : 0;
                              distG = Math.sqrt(dxG*dxG + dyG*dyG + dzG*dzG);
                          }
                          var globalSpeed = duration > 0 ? (distG / duration) : 0;
                          if (pi2 > 0) speedIn = inSlopeCurve * globalSpeed;
                          if (pi2 < n - 1) speedOut = outSlopeCurve * globalSpeed;
                          
                          easeInArray.push(new KeyframeEase(speedIn, inInfluence));
                          easeOutArray.push(new KeyframeEase(speedOut, outInfluence));
                      } else {
                          for (var d = 0; d < dim; d++) {
                              var speedIn = 0, speedOut = 0;
                              var dvG = (dim > 1) ? (v2[d] - v1[d]) : (v2 - v1);
                              var globalSpeed = duration > 0 ? (dvG / duration) : 0;
                              if (pi2 > 0) speedIn = inSlopeCurve * globalSpeed;
                              if (pi2 < n - 1) speedOut = outSlopeCurve * globalSpeed;
                              
                              easeInArray.push(new KeyframeEase(speedIn, inInfluence));
                              easeOutArray.push(new KeyframeEase(speedOut, outInfluence));
                          }
                      }
  
                      prop.setTemporalEaseAtKey(k, easeInArray, easeOutArray);
                  } catch (e) {
                      throw new Error("SmartBake err key " + k + ": " + e.toString());
                  }
              }
  
          } else if (prop.propertyType === PropertyType.INDEXED_GROUP ||
                     prop.propertyType === PropertyType.NAMED_GROUP) {
              count += bakeToGroup(prop, points);
          }
      }
      return count;
  }
  
  function solveCubicBezierT(x, p1x, p2x) {
      if (x <= 0) return 0;
      if (x >= 1) return 1;
      var lo = 0, hi = 1, t = x;
      for (var i = 0; i < 14; i++) {
          var mt = 1 - t;
          var bx = 3 * mt * mt * t * p1x + 3 * mt * t * t * p2x + t * t * t;
          if (Math.abs(bx - x) < 0.0005) break;
          if (bx < x) lo = t; else hi = t;
          t = (lo + hi) / 2;
      }
      return t;
  }
  
  function evalPiecewiseBezier(points, x) {
      var seg = 0;
      while (seg < points.length - 2 && x > points[seg+1].x) {
          seg++;
      }
      var p0 = points[seg];
      var p3 = points[seg+1];
      
      var dx = p3.x - p0.x;
      if (dx <= 1e-6) return p3.y;
  
      var localX = (x - p0.x) / dx;
      var nx1 = (p0.cx2 - p0.x) / dx;
      var nx2 = (p3.cx1 - p0.x) / dx;
  
      var t = solveCubicBezierT(localX, nx1, nx2);
      var mt = 1 - t;
      
      return mt*mt*mt*p0.y + 3*mt*mt*t*p0.cy2 + 3*mt*t*t*p3.cy1 + t*t*t*p3.y;
  }
  
  
  // ─────────────────────────────────────────────
  // SHARED HELPERS
  // ─────────────────────────────────────────────
  
  function getSelectedKeyRange(prop) {
      if (!prop.numKeys) return null;
      var first = -1, last = -1;
      for (var k = 1; k <= prop.numKeys; k++) {
          if (prop.keySelected(k)) {
              if (first === -1) first = k;
              last = k;
          }
      }
      if (first === -1) return null;
      return { start: first, end: last };
  }
  
  function generateExpression(type, params, startIdx, endIdx) {
      var isMirrored = params.isMirrored || false;
      
      if (type === "elastic") {
          return [
              "// Elastic / Overshoot — generated by NeuCurve" + (isMirrored ? " (Mirrored)" : ""),
              "var amp = " + params.amplitude.toFixed(4) + ";",
              "var freq = " + params.frequency.toFixed(4) + ";",
              "var decay = " + params.decay.toFixed(4) + ";",
              "var isMirrored = " + isMirrored + ";",
              "var i1 = " + startIdx + ";",
              "var i2 = " + endIdx + ";",
              "if (numKeys < i2) value;",
              "else {",
              "  var t1 = key(i1).time;",
              "  var t2 = key(i2).time;",
              "  if (time < t1 || time > t2) value;",
              "  else {",
              "    var t = (time - t1) / (t2 - t1);",
              "    if (isMirrored) t = 1 - t;",
              "    var ease = 1 - amp * Math.exp(-decay * t) * Math.cos(freq * Math.PI * 2 * t);",
              "    var finalEase = isMirrored ? (1 - ease) : ease;",
              "    try {",
              "      var v1 = key(i1).value, v2 = key(i2).value;",
              "      v1 + (v2 - v1) * finalEase;",
              "    } catch(e) {",
              "      valueAtTime(t1 + (t2 - t1) * finalEase);",
              "    }",
              "  }",
              "}"
          ].join("\n");
      }
  
      if (type === "bounce") {
          return [
              "// Bounce Physical — generated by NeuCurve" + (isMirrored ? " (Mirrored)" : ""),
              "var bounces = " + Math.round(params.bounces) + ";",
              "var stiffness = " + params.stiffness.toFixed(4) + ";",
              "var isMirrored = " + isMirrored + ";",
              "var i1 = " + startIdx + ";",
              "var i2 = " + endIdx + ";",
              "if (numKeys < i2) value;",
              "else {",
              "  var t1 = key(i1).time;",
              "  var t2 = key(i2).time;",
              "  if (time < t1 || time > t2) value;",
              "  else {",
              "    var t = (time - t1) / (t2 - t1);",
              "    if (isMirrored) t = 1 - t;",
              "    var segs = bounces + 1;",
              "    var seg = Math.min(Math.floor(t * segs), segs - 1);",
              "    var ease;",
              "    if (seg == 0) {",
              "      var lt = t * segs;",
              "      ease = lt * lt;",
              "    } else {",
              "      var segMid = (seg + 0.5) / segs;",
              "      var halfWidth = 0.5 / segs;",
              "      var nt = (t - segMid) / halfWidth;",
              "      ease = 1 - Math.pow(stiffness, seg) * (1 - nt * nt);",
              "    }",
              "    var finalEase = isMirrored ? (1 - ease) : ease;",
              "    try {",
              "      var v1 = key(i1).value, v2 = key(i2).value;",
              "      v1 + (v2 - v1) * finalEase;",
              "    } catch(e) {",
              "      valueAtTime(t1 + (t2 - t1) * finalEase);",
              "    }",
              "  }",
              "}"
          ].join("\n");
      }
  
      if (type === "custom") {
          var pts = params.points;
          var ptsLiteral = "[";
          for (var i = 0; i < pts.length; i++) {
              var pt = pts[i];
              ptsLiteral += "[" +
                  pt.x.toFixed(4) + "," + pt.y.toFixed(4) + "," +
                  pt.cx1.toFixed(4) + "," + pt.cy1.toFixed(4) + "," +
                  pt.cx2.toFixed(4) + "," + pt.cy2.toFixed(4) +
              "]";
              if (i < pts.length - 1) ptsLiteral += ",";
          }
          ptsLiteral += "]";
  
          return [
              "// Custom Path — generated by NeuCurve" + (isMirrored ? " (Mirrored)" : ""),
              "var pts = " + ptsLiteral + ";",
              "var isMirrored = " + isMirrored + ";",
              "var i1 = " + startIdx + ";",
              "var i2 = " + endIdx + ";",
              "if (numKeys < i2) value;",
              "else {",
              "  var t1 = key(i1).time;",
              "  var t2 = key(i2).time;",
              "  if (time < t1 || time > t2) value;",
              "  else {",
              "    var t = Math.max(0, Math.min(1, (time - t1) / (t2 - t1)));",
              "    if (isMirrored) t = 1 - t;",
              "    var seg = 0;",
              "    while (seg < pts.length - 2 && t > pts[seg+1][0]) {",
              "      seg++;",
              "    }",
              "    var p0 = pts[seg]; var p3 = pts[seg+1];",
              "    var dx = p3[0] - p0[0];",
              "    var ease;",
              "    if (dx <= 1e-6) {",
              "      ease = p3[1];",
              "    } else {",
              "      var localX = (t - p0[0]) / dx;",
              "      var nx1 = (p0[4] - p0[0]) / dx;",
              "      var nx2 = (p3[2] - p0[0]) / dx;",
              "      var lo = 0, hi = 1, bzT = localX;",
              "      for (var j = 0; j < 14; j++) {",
              "        var mt = 1 - bzT;",
              "        var bx = 3 * mt * mt * bzT * nx1 + 3 * mt * bzT * bzT * nx2 + bzT * bzT * bzT;",
              "        if (Math.abs(bx - localX) < 0.0005) break;",
              "        if (bx < localX) lo = bzT; else hi = bzT;",
              "        bzT = (lo + hi) / 2;",
              "      }",
              "      var bzMt = 1 - bzT;",
              "      ease = bzMt*bzMt*bzMt*p0[1] + 3*bzMt*bzMt*bzT*p0[5] + 3*bzMt*bzT*bzT*p3[3] + bzT*bzT*bzT*p3[1];",
              "    }",
              "    var finalEase = isMirrored ? (1 - ease) : ease;",
              "    try {",
              "      var v1 = key(i1).value, v2 = key(i2).value;",
              "      v1 + (v2 - v1) * finalEase;",
              "    } catch(e) {",
              "      valueAtTime(t1 + (t2 - t1) * finalEase);",
              "    }",
              "  }",
              "}"
          ].join("\n");
      }
  
      if (type === "wave") {
          return [
              "// Wave — generated by NeuCurve" + (isMirrored ? " (Mirrored)" : ""),
              "var freq = " + params.frequency.toFixed(4) + ";",
              "var decay = " + params.decay.toFixed(4) + ";",
              "var sharp = " + params.sharpness.toFixed(4) + ";",
              "var isMirrored = " + isMirrored + ";",
              "var i1 = " + startIdx + ";",
              "var i2 = " + endIdx + ";",
              "if (numKeys < i2) value;",
              "else {",
              "  var t1 = key(i1).time;",
              "  var t2 = key(i2).time;",
              "  var t = (time - t1) / (t2 - t1);",
              "  if (time < t1) value;",
              "  else {",
              "    if (t > 1) t = 1;",
              "    if (isMirrored) t = 1 - t;",
              "    var phase = t * freq;",
              "    var sig = Math.sin(phase * Math.PI * 2 - Math.PI / 2);",
              "    var s = 0.5 + 0.5 * sig;",
              "    var tr = Math.abs(((phase + 0.5) % 1) * 2 - 1);",
              "    var osc;",
              "    if (sharp > 0) osc = s + (tr - s) * sharp;",
              "    else {",
              "      var exponent = 1.0 / (1.0 + Math.abs(sharp));",
              "      var shaped = (sig < 0 ? -1 : 1) * Math.pow(Math.abs(sig), exponent);",
              "      osc = 0.5 + 0.5 * shaped;",
              "    }",
              "    var envelope = Math.exp(-decay * t);",
              "    var ease = 0.5 + (osc - 0.5) * 1.0 * envelope;",
              "    var finalEase = isMirrored ? (1 - ease) : ease;",
              "    try {",
              "      var v1 = key(i1).value, v2 = key(i2).value;",
              "      v1 + (v2 - v1) * finalEase;",
              "    } catch(e) {",
              "      valueAtTime(t1 + (t2 - t1) * finalEase);",
              "    }",
              "  }",
              "}"
          ].join("\n");
      }
  
      return "";
  }
  
  // ─────────────────────────────────────────────
  // MODEL 6 — WAVE
  // ─────────────────────────────────────────────
  
  function applyWave(jsonParams) {
      var p = JSON.parse(jsonParams);
      app.beginUndoGroup("NeuCurve: Apply Wave");
      try {
          var count = applyExpressionToSelected(p, "wave");
          app.endUndoGroup();
          return JSON.stringify({ success: true, keyframesModified: count });
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  function applyExpressionToSelected(params, type) {
      var count = 0;
      var comp = app.project.activeItem;
      if (!comp || !(comp instanceof CompItem)) return count;
      
      // GUARD CLAUSE: Do nothing if no layers are selected
      if (comp.selectedLayers.length === 0) return count;
  
      for (var i = 0; i < comp.selectedLayers.length; i++) {
          var layer = comp.selectedLayers[i];
          count += applyExprToGroup(layer, params, type);
      }
      return count;
  }
  
  function applyExprToGroup(propGroup, params, type) {
      var count = 0;
      if (!propGroup) return count;
      for (var i = 1; i <= propGroup.numProperties; i++) {
          var prop = propGroup.property(i);
          if (prop.propertyType === PropertyType.PROPERTY) {
              var pvt = prop.propertyValueType;
              if (pvt === PropertyValueType.SHAPE || pvt === PropertyValueType.CUSTOM_VALUE) continue;
  
              if (type === "remove") {
                  if (prop.canSetExpression && prop.expression !== "") {
                      prop.expression = "";
                      count++;
                  }
                  continue;
              }
  
              var range = getSelectedKeyRange(prop);
              if (range && prop.canSetExpression) {
                  var expr = generateExpression(type, params, range.start, range.end);
                  if (expr !== "") {
                      prop.expression = expr;
                      count++;
                  }
              }
          } else if (prop.propertyType === PropertyType.INDEXED_GROUP ||
                     prop.propertyType === PropertyType.NAMED_GROUP) {
              count += applyExprToGroup(prop, params, type);
          }
      }
      return count;
  }
  
  function removeExpressions() {
      app.beginUndoGroup("NeuCurve: Remove Expressions");
      try {
          var count = applyExpressionToSelected(null, "remove");
          app.endUndoGroup();
          return JSON.stringify({ success: true, modified: count });
      } catch (e) {
          app.endUndoGroup();
          return JSON.stringify({ error: e.toString() });
      }
  }
  
  
  function getPlayheadInfo() {
      var comp = app.project.activeItem;
      if (!comp || !(comp instanceof CompItem)) return JSON.stringify({ error: "no active comp" });
  
      var result = {
          time: comp.time,
          range: null
      };
  
      try {
          // Strategy 1: Check selectedProperties first (if user selected properties directly)
          var selProps = comp.selectedProperties;
          if (selProps && selProps.length > 0) {
              for (var pi = 0; pi < selProps.length; pi++) {
                  var sp = selProps[pi];
                  if (sp.numKeys && sp.numKeys > 1) {
                      var range = getSelectedKeyRange(sp);
                      if (range) {
                          result.range = [sp.keyTime(range.start), sp.keyTime(range.end)];
                      } else {
                          // Fallback to all keyframes if none selected
                          result.range = [sp.keyTime(1), sp.keyTime(sp.numKeys)];
                      }
                      break;
                  }
              }
          }
  
          // Strategy 2: If still no range, scan selected layers for any animated property
          if (!result.range) {
              var layers = comp.selectedLayers;
              if (layers && layers.length > 0) {
                  for (var li = 0; li < layers.length; li++) {
                      var lyr = layers[li];
                      var found = searchLayerForKeys(lyr);
                      if (found) {
                          result.range = found;
                          break;
                      }
                  }
              }
          }
  
          // Strategy 3: Last resort — scan ALL layers
          if (!result.range) {
              for (var ai = 1; ai <= comp.numLayers; ai++) {
                  var aLyr = comp.layer(ai);
                  var af = searchLayerForKeys(aLyr);
                  if (af) {
                      result.range = af;
                      break;
                  }
              }
          }
      } catch (e) {
          result.error = e.toString();
      }
  
      return JSON.stringify(result);
  }
  
  function searchLayerForKeys(lyr) {
      try {
          for (var gi = 1; gi <= lyr.numProperties; gi++) {
              var grp = lyr.property(gi);
              if (!grp || !grp.numProperties) continue;
              for (var pi2 = 1; pi2 <= grp.numProperties; pi2++) {
                  var prop = grp.property(pi2);
                  if (!prop) continue;
                  try {
                      if (prop.numKeys && prop.numKeys > 1) {
                          var range = getSelectedKeyRange(prop);
                          if (range) return [prop.keyTime(range.start), prop.keyTime(range.end)];
                          return [prop.keyTime(1), prop.keyTime(prop.numKeys)];
                      }
                  } catch (e2) {}
                  // Recurse into sub-groups (like Transform > Position)
                  try {
                      if (prop.numProperties) {
                          for (var si = 1; si <= prop.numProperties; si++) {
                              var sub = prop.property(si);
                              if (sub && sub.numKeys && sub.numKeys > 1) {
                                  var subRange = getSelectedKeyRange(sub);
                                  if (subRange) return [sub.keyTime(subRange.start), sub.keyTime(subRange.end)];
                                  return [sub.keyTime(1), sub.keyTime(sub.numKeys)];
                              }
                          }
                      }
                  } catch (e3) {}
              }
          }
      } catch (e4) {}
      return null;
  }
  
  
  function ping() {
      return JSON.stringify({
          status: "ok",
          aeVersion: app.version,
          activeComp: app.project.activeItem ? app.project.activeItem.name : null
      });
  }
  
  function readGraphFromAE() {
      try {
          var comp = app.project.activeItem;
          if (!comp || !(comp instanceof CompItem)) {
              return JSON.stringify({ error: "Tidak ada komposisi aktif." });
          }
  
          var selProps = comp.selectedProperties;
          if (!selProps || selProps.length === 0) {
              return JSON.stringify({ error: "Silakan seleksi properti yang memiliki keyframe." });
          }
  
          var prop = selProps[0];
          if (prop.propertyType !== PropertyType.PROPERTY || prop.numKeys < 2) {
              return JSON.stringify({ error: "Properti tidak memiliki cukup keyframe." });
          }
  
          var selKeys = [];
          for (var k = 1; k <= prop.numKeys; k++) {
              if (prop.keySelected(k)) selKeys.push(k);
          }
  
          // If less than 2 keyframes selected, try to read the first 2 keyframes or the whole property
          if (selKeys.length < 2) {
              if (prop.numKeys >= 2) {
                  selKeys = [];
                  for (var k = 1; k <= prop.numKeys; k++) selKeys.push(k);
              } else {
                  return JSON.stringify({ error: "Butuh minimal 2 keyframe untuk membaca kurva." });
              }
          }
  
          var kFirst = selKeys[0];
          var kLast = selKeys[selKeys.length - 1];
          
          var t1 = prop.keyTime(kFirst);
          var t2 = prop.keyTime(kLast);
          var duration = t2 - t1;
          if (duration <= 0) return JSON.stringify({ error: "Durasi antar keyframe adalah 0." });
  
          var v1 = prop.keyValue(kFirst);
          var v2 = prop.keyValue(kLast);
  
          var valType = prop.propertyValueType;
          var dim = (v1 !== undefined && v1.length !== undefined) ? v1.length : 1;
          var isSpatial = (valType === PropertyValueType.TwoD_SPATIAL || valType === PropertyValueType.ThreeD_SPATIAL);
          var isColorProp = (valType === PropertyValueType.COLOR);
  
          var distG = 0;
          if (isSpatial) {
              var dxG = v2[0] - v1[0], dyG = v2[1] - v1[1], dzG = (dim === 3) ? (v2[2] - v1[2]) : 0;
              distG = Math.sqrt(dxG*dxG + dyG*dyG + dzG*dzG);
          } else if (isColorProp) {
              distG = 1; // dummy for color
          } else {
              distG = (dim > 1) ? (v2[0] - v1[0]) : (v2 - v1);
          }
  
          var globalSpeed = duration > 0 ? (distG / duration) : 0;
          if (Math.abs(globalSpeed) < 0.0001) {
              globalSpeed = 0;
          }
  
          var points = [];
          for (var i = 0; i < selKeys.length; i++) {
              var kIdx = selKeys[i];
              var tTime = prop.keyTime(kIdx);
              var val = prop.keyValue(kIdx);
  
              var ptX = (tTime - t1) / duration;
              var ptY = 0;
  
              if (isSpatial) {
                  var c_dx = val[0] - v1[0], c_dy = val[1] - v1[1], c_dz = (dim === 3) ? (val[2] - v1[2]) : 0;
                  var c_dist = Math.sqrt(c_dx*c_dx + c_dy*c_dy + c_dz*c_dz);
                  ptY = (distG !== 0) ? (c_dist / distG) : ptX;
              } else if (isColorProp) {
                  ptY = ptX;
              } else {
                  var c_v = (dim > 1) ? val[0] : val;
                  var c_v1 = (dim > 1) ? v1[0] : v1;
                  ptY = (distG !== 0) ? ((c_v - c_v1) / distG) : ptX;
              }
  
              var pt = { x: ptX, y: ptY, cx1: ptX, cy1: ptY, cx2: ptX, cy2: ptY };
  
              if (i > 0) {
                  var easeIn = prop.keyInTemporalEase(kIdx)[0];
                  var inInf = easeIn.influence / 100;
                  var inSpeed = easeIn.speed;
  
                  var prevT = prop.keyTime(selKeys[i-1]);
                  var segDurIn = (tTime - prevT) / duration;
                  var dxIn = inInf * segDurIn;
                  pt.cx1 = pt.x - dxIn;
  
                  if (globalSpeed !== 0) {
                      var inSlope = inSpeed / globalSpeed;
                      pt.cy1 = pt.y - inSlope * dxIn;
                  } else {
                      pt.cy1 = pt.y;
                  }
              }
  
              if (i < selKeys.length - 1) {
                  var easeOut = prop.keyOutTemporalEase(kIdx)[0];
                  var outInf = easeOut.influence / 100;
                  var outSpeed = easeOut.speed;
  
                  var nextT = prop.keyTime(selKeys[i+1]);
                  var segDurOut = (nextT - tTime) / duration;
                  var dxOut = outInf * segDurOut;
                  pt.cx2 = pt.x + dxOut;
  
                  if (globalSpeed !== 0) {
                      var outSlope = outSpeed / globalSpeed;
                      pt.cy2 = pt.y + outSlope * dxOut;
                  } else {
                      pt.cy2 = pt.y;
                  }
              }
  
              points.push(pt);
          }
  
          if (selKeys.length === 2) {
              var p0 = points[0];
              var p1 = points[1];
              return JSON.stringify({
                  success: true,
                  model: 0,
                  params: {
                      p1x: p0.cx2,
                      p1y: p0.cy2,
                      p2x: p1.cx1,
                      p2y: p1.cy1,
                      isMirrored: false
                  }
              });
          } else {
              return JSON.stringify({
                  success: true,
                  model: 4,
                  params: {
                      points: points,
                      isMirrored: false
                  }
              });
          }
      } catch (e) {
          return JSON.stringify({ error: e.toString() });
      }
  }

  // NeuCurve global exports
  $.global.applyCubicBezier = applyCubicBezier;
  $.global.applyElastic = applyElastic;
  $.global.applyBounce = applyBounce;
  $.global.applySteps = applySteps;
  $.global.applyCustomPath = applyCustomPath;
  $.global.applyWave = applyWave;
  $.global.removeExpressions = removeExpressions;
  $.global.readGraphFromAE = readGraphFromAE;
  $.global.getPlayheadInfo = getPlayheadInfo;

  $.global.applyNamedEffect = applyNamedEffect;
  $.global.applyCurveEase = applyCurveEase;
  $.global.applyCurveEaseExt = applyCurveEaseExt;
  $.global.setAEShortcutExt = setAEShortcutExt;
  $.global.clearAEShortcutExt = clearAEShortcutExt;
  $.global.runScriptSlotExt = runScriptSlotExt;
  $.global.centerLayer = centerLayer;
  $.global.fitToComp = fitToComp;
  $.global.setAnchor = setAnchor;
  $.global.freezeFrame = freezeFrame;
  $.global.makeAdjustmentLayer = makeAdjustmentLayer;
  $.global.makeNull = makeNull;
  $.global.makeSolid = makeSolid;
  $.global.makeCamera = makeCamera;
  $.global.applyFill = applyFill;
  $.global.applyFastBlur = applyFastBlur;
  $.global.applyTint = applyTint;
  $.global.precomposeSelected = precomposeSelected;
  $.global.precomposeEach = precomposeEach;
  $.global.browseForPreset = browseForPreset;
  $.global.applyPresetFile = applyPresetFile;
  $.global.saveFrame = saveFrame;

  // ── NEW: Project clean functions ─────────────────────────────────────────
  function removeUnusedFootage(){
    try{
      app.beginUndoGroup('EllieTools — Remove Unused');
      app.project.reduceProject(app.project.activeItem);
      return 'Unused footage removed.';
    }catch(e){ return '⚠ '+e.message; }
    finally{ try{app.endUndoGroup();}catch(x){} }
  }
  function consolidateFootage(){
    try{
      app.beginUndoGroup('EllieTools — Consolidate');
      app.project.consolidateFootage();
      return 'Footage consolidated.';
    }catch(e){ return '⚠ '+e.message; }
    finally{ try{app.endUndoGroup();}catch(x){} }
  }
  $.global.removeUnusedFootage = removeUnusedFootage;
  $.global.consolidateFootage  = consolidateFootage;
})();
