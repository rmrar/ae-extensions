(function (thisObj) {
// ----- EXTENDSCRIPT INCLUDES ------ //
"object"!=typeof JSON&&(JSON={}),function(){"use strict";var rx_one=/^[\],:{}\s]*$/,rx_two=/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,rx_three=/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,rx_four=/(?:^|:|,)(?:\s*\[)+/g,rx_escapable=/[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,rx_dangerous=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,gap,indent,meta,rep;function f(t){return t<10?"0"+t:t}function this_value(){return this.valueOf()}function quote(t){return rx_escapable.lastIndex=0,rx_escapable.test(t)?'"'+t.replace(rx_escapable,function(t){var e=meta[t];return"string"==typeof e?e:"\\u"+("0000"+t.charCodeAt(0).toString(16)).slice(-4)})+'"':'"'+t+'"'}function str(t,e){var r,n,o,u,f,a=gap,i=e[t];switch(i&&"object"==typeof i&&"function"==typeof i.toJSON&&(i=i.toJSON(t)),"function"==typeof rep&&(i=rep.call(e,t,i)),typeof i){case"string":return quote(i);case"number":return isFinite(i)?String(i):"null";case"boolean":case"null":return String(i);case"object":if(!i)return"null";if(gap+=indent,f=[],"[object Array]"===Object.prototype.toString.apply(i)){for(u=i.length,r=0;r<u;r+=1)f[r]=str(r,i)||"null";return o=0===f.length?"[]":gap?"[\n"+gap+f.join(",\n"+gap)+"\n"+a+"]":"["+f.join(",")+"]",gap=a,o}if(rep&&"object"==typeof rep)for(u=rep.length,r=0;r<u;r+=1)"string"==typeof rep[r]&&(o=str(n=rep[r],i))&&f.push(quote(n)+(gap?": ":":")+o);else for(n in i)Object.prototype.hasOwnProperty.call(i,n)&&(o=str(n,i))&&f.push(quote(n)+(gap?": ":":")+o);return o=0===f.length?"{}":gap?"{\n"+gap+f.join(",\n"+gap)+"\n"+a+"}":"{"+f.join(",")+"}",gap=a,o}}"function"!=typeof Date.prototype.toJSON&&(Date.prototype.toJSON=function(){return isFinite(this.valueOf())?this.getUTCFullYear()+"-"+f(this.getUTCMonth()+1)+"-"+f(this.getUTCDate())+"T"+f(this.getUTCHours())+":"+f(this.getUTCMinutes())+":"+f(this.getUTCSeconds())+"Z":null},Boolean.prototype.toJSON=this_value,Number.prototype.toJSON=this_value,String.prototype.toJSON=this_value),"function"!=typeof JSON.stringify&&(meta={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"},JSON.stringify=function(t,e,r){var n;if(gap="",indent="","number"==typeof r)for(n=0;n<r;n+=1)indent+=" ";else"string"==typeof r&&(indent=r);if(rep=e,e&&"function"!=typeof e&&("object"!=typeof e||"number"!=typeof e.length))throw new Error("JSON.stringify");return str("",{"":t})}),"function"!=typeof JSON.parse&&(JSON.parse=function(text,reviver){var j;function walk(t,e){var r,n,o=t[e];if(o&&"object"==typeof o)for(r in o)Object.prototype.hasOwnProperty.call(o,r)&&(void 0!==(n=walk(o,r))?o[r]=n:delete o[r]);return reviver.call(t,e,o)}if(text=String(text),rx_dangerous.lastIndex=0,rx_dangerous.test(text)&&(text=text.replace(rx_dangerous,function(t){return"\\u"+("0000"+t.charCodeAt(0).toString(16)).slice(-4)})),rx_one.test(text.replace(rx_two,"@").replace(rx_three,"]").replace(rx_four,"")))return j=eval("("+text+")"),"function"==typeof reviver?walk({"":j},""):j;throw new SyntaxError("JSON.parse")})}();
// ---------------------------------- //
// ----- EXTENDSCRIPT PONYFILLS -----
function __objectFreeze(obj) { return obj; }
// ---------------------------------- //
var version = "0.0.1";

var config = {
  version: version,
  id: "com.ellietools.cep",
  displayName: "EllieTools",
  symlink: "local",
  port: 3000,
  servePort: 5000,
  startingDebugPort: 8860,
  extensionManifestVersion: 6.0,
  requiredRuntimeVersion: 9.0,
  hosts: [{
    name: "AEFT",
    version: "[0.0,99.9]"
  }],
  type: "Panel",
  iconDarkNormal: "./src/assets/light-icon.png",
  iconNormal: "./src/assets/dark-icon.png",
  iconDarkNormalRollOver: "./src/assets/light-icon.png",
  iconNormalRollOver: "./src/assets/dark-icon.png",
  parameters: ["--v=0", "--enable-nodejs", "--mixed-context"],
  width: 330,
  height: 361,
  panels: [{
    mainPath: "./main/index.html",
    name: "main",
    panelDisplayName: "EllieTools",
    autoVisible: true,
    width: 330,
    height: 361
  }],
  build: {
    jsxBin: "off",
    sourceMap: true
  },
  zxp: {
    country: "US",
    province: "CA",
    org: "MyCompany",
    password: "mypassword",
    tsa: "http://timestamp.digicert.com/",
    sourceMap: false,
    jsxBin: "copy"
  },
  installModules: [],
  copyAssets: [],
  copyZipAssets: []
};

var ns = config.id;

var executeTool = function executeTool(toolName, arg1, arg2) {
  try {
    return tools[toolName](arg1, arg2);
  } catch (error) {
    alert([error.line, error].toString());
  }
};
var getSettings = function getSettings(settings) {
  try {
    var SETTINGS = getSettingsFromUI(settings);
    if (!Folder(SETTINGS.path).exists) {
      alert("Please select folder that exists");
      return false;
    }
    return SETTINGS;
  } catch (error) {
    alert([error.line, error].toString());
  }
};

//prettier-ignore
var tools = {
  // Row 1
  FRZ: function FRZ() {
    return _FRZ();
  },
  FIT: function FIT(alter) {
    return _FIT(alter);
  },
  DSH: function DSH() {
    return _DSH();
  },
  MIR: function MIR(alter) {
    return _MIR(alter);
  },
  ADJ: function ADJ() {
    return _ADJ();
  },
  // Row 2
  SHA: function SHA() {
    return _SHA();
  },
  SOL: function SOL(alter) {
    return _SOL(alter);
  },
  NUL: function NUL() {
    return _NUL();
  },
  CAM: function CAM() {
    return _CAM();
  },
  HUE: function HUE() {
    return _HUE();
  },
  // Row 3 Effects
  FILL: function FILL() {
    return _FILL();
  },
  TINT: function TINT() {
    return _TINT();
  },
  BLUR: function BLUR(alter) {
    return _BLUR(alter);
  },
  LUM: function LUM() {
    return _LUM();
  },
  CURV: function CURV() {
    return _CURV();
  },
  //actions
  PRECOMP: function PRECOMP() {
    return _PRECOMP();
  },
  CENTERINCOMP: function CENTERINCOMP() {
    return _CENTERINCOMP();
  },
  SAVEFRAME: function SAVEFRAME(SETTINGS) {
    return _SAVEFRAME(SETTINGS);
  },
  setAnchorPoint: function setAnchorPoint(pos) {
    return _setAnchorPoint(pos);
  }
};

// ROW 1
function _FRZ() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;
  app.beginUndoGroup("Apply Freeze Frames");
  // Get current time
  var currentTime = comp.time;

  // Process each selected layer
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];

    // Skip if layer doesn't support time remapping
    if (!layer.canSetTimeRemapEnabled) continue;

    //if CTI is out of range of the layer, skip - ??, if alter ignore
    if ((currentTime < layer.inPoint || currentTime > layer.outPoint)) continue;

    // Enable time remapping
    layer.timeRemapEnabled = true;

    // Get time remap property
    layer.property("ADBE Time Remapping");
    app.executeCommand(3695);

    //   // Add keyframe at current time
    //   var currentValue = timeRemap.valueAtTime(currentTime, true);
    //   timeRemap.setValueAtTime(currentTime, currentValue);

    //   // // Add keyframe one frame later with same value to create freeze
    //   // timeRemap.setValueAtTime(currentTime + comp.frameDuration, currentValue);

    //   // Set temporal interpolation to hold
    //   var currentKeyIndex = timeRemap.nearestKeyIndex(currentTime);
    //   timeRemap.setInterpolationTypeAtKey(
    //     currentKeyIndex,
    //     KeyframeInterpolationType.HOLD
    //   );

    //   // Trim layer out point
    //   layer.outPoint = comp.duration;
    // }
  }
  app.endUndoGroup();
  return true;
}
function _FIT(alter) {
  var alter = alter === undefined ? false : alter;
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;
  if (selectedLayers.length == 0) return false;
  app.beginUndoGroup("Fit to Comp");
  alter ? app.executeCommand(2733) : app.executeCommand(2732);
  app.endUndoGroup();
  return true;
}
function _DSH() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;
  if (selectedLayers.length == 0) return false;
  app.beginUndoGroup("Add Drop Shadow");
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    var shadow = layer.Effects.addProperty("ADBE Drop Shadow");
    shadow.property(4).setValue(10); // Distance
    shadow.property(5).setValue(100); // Softness
    // shadow.property(2).setValue(75); // Opacity
  }
  app.endUndoGroup();
  return true;
}
function _MIR(alter) {
  var alter = alter === undefined ? false : alter;
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;
  if (selectedLayers.length == 0) return false;
  app.beginUndoGroup("Mirror");
  alter ? app.executeCommand(3767) : app.executeCommand(3766);
  app.endUndoGroup();
  return true;
}
function _ADJ() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;
  var hasSelection = comp.selectedLayers.length > 0;
  //   app.project.item(index).layer(index).moveBefore(layer)
  app.beginUndoGroup("Create Adjustment Layer");

  //save selection, because after adding new layer, the selection is
  var targetLayer = hasSelection ? selectedLayers[0] : null;
  var adjLayer = comp.layers.addSolid([1, 1, 1], "Adjustment Layer", comp.width, comp.height, 1);
  adjLayer.adjustmentLayer = true;
  adjLayer.label = 5;
  if (hasSelection) {
    adjLayer.inPoint = targetLayer.inPoint;
    adjLayer.outPoint = targetLayer.outPoint;
    adjLayer.moveBefore(targetLayer);
  }
  app.endUndoGroup();
  return true;
}

// ROW 2
function _SHA() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;
  var hasSelection = comp.selectedLayers.length > 0;
  var targetLayer = hasSelection ? selectedLayers[0] : null;
  app.beginUndoGroup("Create Shape Layer");

  // Create shape layer
  var shapeLayer = comp.layers.addShape();

  // Set layer name
  shapeLayer.name = "Shape Layer";
  shapeLayer.label = 8;

  // Calculate dimensions (30% of comp size)
  // var rectWidth = comp.width * 0.3;
  // var rectHeight = comp.height * 0.3;

  // // Generate random color (values between 0 and 1)
  // var randomColor = [
  //   generateRandomNumber(),
  //   generateRandomNumber(),
  //   generateRandomNumber(),
  // ];

  // // Create rectangle shape
  // var shapeGroup = shapeLayer
  //   .property("ADBE Root Vectors Group")
  //   .addProperty("ADBE Vector Group");

  // var vectorShape = shapeGroup
  //   .property("ADBE Vectors Group")
  //   .addProperty("ADBE Vector Shape - Rect");

  // var a = 1;
  // // Set rectangle size
  // vectorShape
  //   .property("ADBE Vector Rect Size")
  //   .setValue([rectWidth, rectHeight]);

  // var fillProperty = shapeGroup
  //   .property("ADBE Vectors Group")
  //   .addProperty("ADBE Vector Graphic - Fill");

  // // Set random fill color
  // fillProperty.property("ADBE Vector Fill Color").setValue(randomColor);

  // // Add stroke with 0 width
  // var strokeProperty = shapeGroup
  //   .property("ADBE Vectors Group")
  //   .addProperty("ADBE Vector Graphic - Stroke");

  // // Set stroke width to 0
  // strokeProperty.property("ADBE Vector Stroke Width").setValue(0);

  // Set in/out points if there's a selection
  if (hasSelection) {
    shapeLayer.inPoint = targetLayer.inPoint;
    shapeLayer.outPoint = targetLayer.outPoint;
    shapeLayer.moveBefore(targetLayer);
  }
  app.endUndoGroup();
  return true;
}
function _SOL(alter) {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = comp.selectedLayers;
  var hasSelection = selectedLayers.length > 0;
  var targetLayer = hasSelection ? selectedLayers[0] : null;
  app.beginUndoGroup("Create Solid Layer");

  // Create a solid layer with any initial color (white, for example)
  var solidLayer = comp.layers.addSolid([0, 0, 0],
  // Initial white color
  "Solid Layer", comp.width, comp.height, 1);

  // Add "Fill" effect
  var fillEffect = solidLayer.Effects.addProperty("ADBE Fill");

  // Generate random color
  var randomColor = [generateRandomNumber(), generateRandomNumber(), generateRandomNumber()];

  // Set the fill color to the random color
  fillEffect.property("ADBE Fill-0002").setValue(alter ? [0, 0, 0] : randomColor);

  // Set layer label
  solidLayer.label = 1;
  // solidLayer.label = Math.floor(generateRandomNumber() * 17);

  if (hasSelection) {
    solidLayer.inPoint = targetLayer.inPoint;
    solidLayer.outPoint = targetLayer.outPoint;
    solidLayer.moveBefore(targetLayer);
  }
  app.endUndoGroup();
  return true;
}
function _NUL() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = comp.selectedLayers;
  var hasSelection = selectedLayers.length > 0;
  var targetLayer = hasSelection ? selectedLayers[0] : null;
  app.beginUndoGroup("Create Null Object");
  var nullLayer = comp.layers.addNull();
  nullLayer.name = "Null";

  // Set layer label
  nullLayer.label = 1;
  if (hasSelection) {
    nullLayer.inPoint = targetLayer.inPoint;
    nullLayer.outPoint = targetLayer.outPoint;
    nullLayer.moveBefore(targetLayer);
  }
  app.endUndoGroup();
}
function _CAM() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Create Camera");
  var selectedLayers = comp.selectedLayers;
  var hasSelection = comp.selectedLayers.length > 0;
  var targetLayer = hasSelection ? selectedLayers[0] : null;
  app.executeCommand(2564);
  // app.executeCommand(app.findMenuCommandId("Camera..."));

  var l = app.project.activeItem.selectedLayers[0];
  if (l && l.matchName == "ADBE Camera Layer") {
    if (hasSelection) {
      l.inPoint = targetLayer.inPoint;
      l.outPoint = targetLayer.outPoint;
      l.moveBefore(targetLayer);
    }
  }
  app.endUndoGroup();
}
function _HUE() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Add Hue/saturation");
  var selectedLayers = app.project.activeItem.selectedLayers;
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    layer.Effects.addProperty("ADBE HUE SATURATION");
  }
  app.endUndoGroup();
  return true;
}

// Row 3 Effects
function _FILL() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Add Fill Effect");
  var selectedLayers = app.project.activeItem.selectedLayers;
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    layer.Effects.addProperty("ADBE Fill");
  }
  app.endUndoGroup();
  return true;
}
function _TINT() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Add Tint Effect");
  var selectedLayers = app.project.activeItem.selectedLayers;
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    layer.Effects.addProperty("ADBE Tint");
  }
  app.endUndoGroup();
  return true;
}
function _BLUR(alter) {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Add Camera Lens Blur");
  var selectedLayers = app.project.activeItem.selectedLayers;
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    layer.Effects.addProperty(alter ? "ADBE Camera Lens Blur" : "ADBE Gaussian Blur 2");
  }
  app.endUndoGroup();
  return true;
}
function _LUM() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Add Lumetri Color");
  var selectedLayers = app.project.activeItem.selectedLayers;
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    layer.Effects.addProperty("ADBE Lumetri");
  }
  app.endUndoGroup();
  return true;
}
function _CURV() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  app.beginUndoGroup("Add Curves");
  var selectedLayers = app.project.activeItem.selectedLayers;
  for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    layer.Effects.addProperty("ADBE CurvesCustom");
  }
  app.endUndoGroup();
  return true;
}

//ACTION BUTTONS
function _nextNumberedCompName() {
  var used = {};
  try {
    for (var i = 1; i <= app.project.numItems; i++) {
      var item = app.project.item(i);
      if (item instanceof CompItem && /^[0-9]+$/.test(item.name)) {
        used[parseInt(item.name, 10)] = true;
      }
    }
  } catch (e) {}
  var n = 1;
  while (used[n]) n++;
  return String(n);
}

function _dtFiniteNumber(value) {
  return typeof value === "number" && isFinite(value);
}

function _dtFrameDuration(comp) {
  var fd = comp.frameDuration;
  if (!_dtFiniteNumber(fd) || fd <= 0) {
    var fr = comp.frameRate;
    fd = 1 / ((_dtFiniteNumber(fr) && fr > 0) ? fr : 30);
  }
  return fd;
}

function _dtLayerTargetSpan(layer, comp) {
  var fd = _dtFrameDuration(comp);
  var targetIn = layer.inPoint;
  var targetOut = layer.outPoint;
  var editSpan = targetOut - targetIn;
  var oneFrameCutoff = fd * 1.5;

  try {
    if ((!_dtFiniteNumber(editSpan) || editSpan <= oneFrameCutoff) && layer.source && _dtFiniteNumber(layer.source.duration) && layer.source.duration > oneFrameCutoff) {
      var stretch = 100;
      try { stretch = Number(layer.stretch); } catch (e1) {}
      if (!_dtFiniteNumber(stretch) || stretch === 0) stretch = 100;
      var sourceDurationInCompTime = layer.source.duration * Math.abs(stretch) / 100;
      var fullIn = layer.startTime;
      var fullOut = fullIn + sourceDurationInCompTime;
      if (_dtFiniteNumber(fullIn) && _dtFiniteNumber(fullOut) && (fullOut - fullIn) > oneFrameCutoff) {
        targetIn = fullIn;
        targetOut = fullOut;
      }
    }
  } catch (e2) {}

  try {
    if (targetIn < 0) targetIn = 0;
    if (_dtFiniteNumber(comp.duration) && comp.duration > 0 && targetOut > comp.duration) targetOut = comp.duration;
  } catch (e3) {}

  if (!_dtFiniteNumber(targetIn)) targetIn = layer.inPoint;
  if (!_dtFiniteNumber(targetOut)) targetOut = layer.outPoint;
  if ((targetOut - targetIn) <= oneFrameCutoff) targetOut = targetIn + Math.max(fd, oneFrameCutoff);
  return { inPoint: targetIn, outPoint: targetOut };
}

function _dtRecordMatchesInner(record, inner) {
  try {
    if (record.used) return false;
    if (record.name !== inner.name) return false;
    if (record.source && inner.source && record.source !== inner.source) return false;
    return true;
  } catch (e) { return false; }
}

function _dtFindRecordForInner(records, inner, fallbackIndex) {
  for (var i = 0; i < records.length; i++) {
    if (_dtRecordMatchesInner(records[i], inner)) {
      records[i].used = true;
      return records[i];
    }
  }
  if (fallbackIndex >= 0 && fallbackIndex < records.length && !records[fallbackIndex].used) {
    records[fallbackIndex].used = true;
    return records[fallbackIndex];
  }
  return null;
}

function _PRECOMP() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Please select a composition first.");
    return false;
  }
  var selectedLayers = comp.selectedLayers;
  if (selectedLayers.length === 0) {
    alert("Please select at least one layer to pre-compose.");
    return false;
  }

  app.beginUndoGroup("EllieTools Pre-compose");
  try {
    var layerIndices = [];
    var records = [];
    var fd = _dtFrameDuration(comp);
    var minIn = null;
    var maxOut = null;

    for (var i = 0; i < selectedLayers.length; i++) {
      var lyr = selectedLayers[i];
      var spanInfo = _dtLayerTargetSpan(lyr, comp);
      layerIndices.push(lyr.index);
      var lyrSource = null;
      try { lyrSource = lyr.source ? lyr.source : null; } catch (sourceError) {}
      records.push({ name: lyr.name, source: lyrSource, inPoint: spanInfo.inPoint, outPoint: spanInfo.outPoint, used: false });
      if (minIn === null || spanInfo.inPoint < minIn) minIn = spanInfo.inPoint;
      if (maxOut === null || spanInfo.outPoint > maxOut) maxOut = spanInfo.outPoint;
    }

    var span = maxOut - minIn;
    if (!_dtFiniteNumber(span) || span <= fd) span = fd * 2;

    var newName = _nextNumberedCompName();
    var newComp = comp.layers.precompose(layerIndices, newName, true);
    try { newComp.duration = span; } catch (e1) {}
    try { newComp.workAreaStart = 0; newComp.workAreaDuration = span; } catch (e2) {}

    try {
      for (var j = 1; j <= newComp.numLayers; j++) {
        var inner = newComp.layer(j);
        var rec = _dtFindRecordForInner(records, inner, j - 1);
        var targetIn = rec ? rec.inPoint : minIn;
        var targetOut = rec ? rec.outPoint : maxOut;
        try { inner.startTime = inner.startTime - minIn; } catch (e3) {}
        try { inner.inPoint = Math.max(0, targetIn - minIn); } catch (e4) {}
        try { inner.outPoint = Math.min(span, targetOut - minIn); } catch (e5) {}
      }
    } catch (e6) {}

    try {
      for (var k = 1; k <= comp.numLayers; k++) {
        var parentLayer = comp.layer(k);
        if (parentLayer.source === newComp) {
          parentLayer.startTime = minIn;
          parentLayer.inPoint = minIn;
          parentLayer.outPoint = maxOut;
          comp.time = minIn;
          break;
        }
      }
    } catch (e7) {}

    return true;
  } catch (error) {
    alert("Precomp failed.\n" + error.toString());
    return false;
  } finally {
    app.endUndoGroup();
  }
}
function _CENTERINCOMP() {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    return false;
  }
  var selectedLayers = app.project.activeItem.selectedLayers;

  // Check if any layers are selected
  if (selectedLayers.length === 0) {
    return false;
  }
  app.beginUndoGroup("Center In Composition"); // Start undo group

  try {
    // Get composition dimensions
    var compWidth = comp.width;
    var compHeight = comp.height;

    // Get current time
    var currentTime = comp.time;

    // Process each selected layer
    for (var i = 0; i < selectedLayers.length; i++) {
      var layer = selectedLayers[i];

      // Skip camera, light, and null layers (they don't have anchor points)
      if (layer instanceof CameraLayer || layer instanceof LightLayer || layer.nullLayer) {
        continue;
      }

      // Get the layer's position property
      var position = layer.property("ADBE Transform Group").property("ADBE Position");

      // If position is not locked and can be modified
      if (position.canVaryOverTime) {
        // Center the layer
        var newPosition = [compWidth / 2, compHeight / 2];

        // If it's a 3D layer, maintain the z position
        if (layer.threeDLayer) {
          var currentPos = position.valueAtTime(currentTime, true);
          newPosition.push(currentPos[2]);
        }

        // Check if there are any keyframes
        if (position.numKeys > 0) {
          // Set keyframe at current time with centered position
          position.setValueAtTime(currentTime, newPosition);
        } else {
          // Just set the static position
          position.setValue(newPosition);
        }
      }
    }
    return true;
  } catch (err) {
    return false;
  } finally {
    app.endUndoGroup(); // End undo group
  }
}
// var settings = {
//   path: getDesktopPath(),
//   saveFormat: "TIFF",
// };
// SAVEFRAME(settings, false);
function getSeparator() {
  try {
    return Folder.fs === "Macintosh" ? "/" : "\\";
  } catch (e) {
    return "/";
  }
}

function _SAVEFRAME(SETTINGS) {
  var comp = app.project.activeItem;
  if (!comp || !(comp instanceof CompItem)) {
    alert("Open the comp you want to export first.");
    return SETTINGS || false;
  }

  function _safeName(name) {
    return String(name).replace(/[\\\/:*?"<>|]/g, "_").replace(/^\s+|\s+$/g, "");
  }
  function _defaultExportFolder() {
    try { return Folder.desktop.fsName; } catch (e) { return Folder.myDocuments.fsName; }
  }

  try {
    if (!SETTINGS || !SETTINGS.path || !Folder(SETTINGS.path).exists) {
      SETTINGS = SETTINGS || {};
      SETTINGS.path = _defaultExportFolder();
    }

    var rqItem = app.project.renderQueue.items.add(comp);
    rqItem.timeSpanStart = comp.workAreaStart;
    rqItem.timeSpanDuration = comp.workAreaDuration;

    var outModule = rqItem.outputModule(1);
    outModule.file = new File(SETTINGS.path + getSeparator() + _safeName(comp.name || "active_comp") + ".mov");

    try { app.project.renderQueue.showWindow(true); } catch (e) {}
    return SETTINGS;
  } catch (err) {
    alert("Export failed from the active comp.\n" + err.toString());
    return SETTINGS || false;
  }
}
function getSettingsFromUI(settings) {
  var cb = {
    path: null,
    saveFormat: null
  };
  if (settings) {
    cb.path = settings.path;
    cb.saveFormat = settings.saveFormat;
  } else {
    cb.path = getDesktopPath();
    cb.saveFormat = "PNG";
  }
  var myPanel = buildUI(this, cb); // Pass default path or omit for "Set Path"
  if (myPanel instanceof Window) {
    myPanel.show();
    return cb;
  }
}
function getDesktopPath() {
  if (Folder.fs === "Macintosh") {
    return new Folder("~/Desktop").fsName;
  } else {
    // Windows
    return Folder.desktop.fsName;
  }
}
function timeToTimecode(time, fps, noPadding) {
  var h = Math.floor(time / 3600);
  var m = Math.floor(time % 3600 / 60);
  var s = Math.floor(time % 60);
  var f = Math.floor(time % 1 * fps);
  if (noPadding) {
    return h + "_" + m + "_" + s + "_" + f;
  }
  return pad(h, 2) + "_" + pad(m, 2) + "_" + pad(s, 2) + "_" + pad(f, 2);
}
function pad(n, width) {
  n = n + "";
  return n.length >= width ? n : new Array(width - n.length + 1).join("0") + n;
}


function _applyEffectByMatchName(matchName) {
  try {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
      alert("Open a comp and select a layer first.");
      return false;
    }
    var selectedLayers = comp.selectedLayers;
    if (!selectedLayers || selectedLayers.length === 0) {
      alert("Select at least one layer first.");
      return false;
    }
    app.beginUndoGroup("EllieTools Apply Effect");
    for (var i = 0; i < selectedLayers.length; i++) {
      selectedLayers[i].Effects.addProperty(matchName);
    }
    app.endUndoGroup();
    return true;
  } catch (err) {
    try { app.endUndoGroup(); } catch(e) {}
    alert("Could not apply effect.\n" + err.toString());
    return false;
  }
}

function _applyPresetFromPath(path) {
  try {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
      alert("Open a comp and select a layer first.");
      return false;
    }
    var selectedLayers = comp.selectedLayers;
    if (!selectedLayers || selectedLayers.length === 0) {
      alert("Select at least one layer first.");
      return false;
    }
    var f = new File(path);
    if (!f.exists) {
      alert("Preset file not found:\n" + path);
      return false;
    }
    app.beginUndoGroup("EllieTools Apply Preset");
    for (var i = 0; i < selectedLayers.length; i++) {
      selectedLayers[i].applyPreset(f);
    }
    app.endUndoGroup();
    return true;
  } catch (err) {
    try { app.endUndoGroup(); } catch(e) {}
    alert("Could not apply preset.\n" + err.toString());
    return false;
  }
}

function _jsonEscapeString(str) {
  return String(str).replace(/\\/g, "\\\\").replace(/\"/g, '\\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n");
}

function _listInstalledPresets(query) {
  query = String(query || "").toLowerCase();
  var max = 40;
  var found = [];
  function addPath(f) {
    try {
      var nm = decodeURI(f.name || "");
      if (!/\.ffx$/i.test(nm)) return;
      if (query && nm.toLowerCase().indexOf(query) < 0) return;
      found.push({ name: nm.replace(/\.ffx$/i, ""), path: f.fsName });
    } catch(e) {}
  }
  function scanFolder(folder, depth) {
    if (!folder || !folder.exists || depth < 0 || found.length >= max) return;
    var items;
    try { items = folder.getFiles(); } catch(e) { return; }
    for (var i = 0; i < items.length && found.length < max; i++) {
      if (items[i] instanceof Folder) scanFolder(items[i], depth - 1);
      else addPath(items[i]);
    }
  }
  try { scanFolder(new Folder(app.path.fsName + getSeparator() + "Presets"), 4); } catch(e) {}
  try { scanFolder(new Folder(Folder.myDocuments.fsName + getSeparator() + "Adobe" + getSeparator() + "After Effects"), 5); } catch(e) {}
  var json = "[";
  for (var j = 0; j < found.length; j++) {
    if (j > 0) json += ",";
    json += "{\"name\":\"" + _jsonEscapeString(found[j].name) + "\",\"path\":\"" + _jsonEscapeString(found[j].path) + "\"}";
  }
  json += "]";
  return json;
}


function _applyEffectCandidates(label, candidates) {
  try {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
      alert("Open a comp and select a layer first.");
      return false;
    }
    var selectedLayers = comp.selectedLayers;
    if (!selectedLayers || selectedLayers.length === 0) {
      alert("Select at least one layer first.");
      return false;
    }
    if (!(candidates instanceof Array)) candidates = [label];

    app.beginUndoGroup("EllieTools Apply " + label);
    var failed = [];
    for (var i = 0; i < selectedLayers.length; i++) {
      var layer = selectedLayers[i];
      var added = false;
      var lastErr = "";
      for (var c = 0; c < candidates.length; c++) {
        try {
          layer.Effects.addProperty(candidates[c]);
          added = true;
          break;
        } catch (e) {
          lastErr = e.toString();
        }
      }
      if (!added) failed.push(layer.name + ": " + lastErr);
    }
    app.endUndoGroup();

    if (failed.length > 0) {
      alert("Could not apply " + label + ".\nMake sure the effect/plugin is installed.\n\n" + failed.join("\n"));
      return false;
    }
    return true;
  } catch (err) {
    try { app.endUndoGroup(); } catch(e) {}
    alert("Could not apply " + label + ".\n" + err.toString());
    return false;
  }
}

var aeft = /*#__PURE__*/__objectFreeze({
  __proto__: null,
  executeTool: executeTool,
  getSettings: getSettings,
  applyEffectByMatchName: _applyEffectByMatchName,
  applyPresetFromPath: _applyPresetFromPath,
  listInstalledPresets: _listInstalledPresets,
  applyEffectCandidates: _applyEffectCandidates
});

var host = typeof $ !== "undefined" ? $ : window;

// A safe way to get the app name since some versions of Adobe Apps broken BridgeTalk in various places (e.g. After Effects 24-25)
// in that case we have to do various checks per app to deterimine the app name

var getAppNameSafely = function getAppNameSafely() {
  var compare = function compare(a, b) {
    return a.toLowerCase().indexOf(b.toLowerCase()) > -1;
  };
  var exists = function exists(a) {
    return typeof a !== "undefined";
  };
  var isBridgeTalkWorking = typeof BridgeTalk !== "undefined" && typeof BridgeTalk.appName !== "undefined";
  if (isBridgeTalkWorking) {
    return BridgeTalk.appName;
  } else if (app) {
    
    if (exists(app.name)) {
      
      var name = app.name;
      if (compare(name, "photoshop")) return "photoshop";
      if (compare(name, "illustrator")) return "illustrator";
      if (compare(name, "audition")) return "audition";
      if (compare(name, "bridge")) return "bridge";
      if (compare(name, "indesign")) return "indesign";
    }
    
    if (exists(app.appName)) {
      
      var appName = app.appName;
      if (compare(appName, "after effects")) return "aftereffects";
      if (compare(appName, "animate")) return "animate";
    }
    
    if (exists(app.path)) {
      
      var path = app.path;
      if (compare(path, "premiere")) return "premierepro";
    }
    
    if (exists(app.getEncoderHost) && exists(AMEFrontendEvent)) {
      return "ame";
    }
  }
  return "unknown";
};
switch (getAppNameSafely()) {
  case "aftereffects":
  case "aftereffectsbeta":
    host[ns] = aeft;
    break;
}

// https://extendscript.docsforadobe.dev/interapplication-communication/bridgetalk-class.html?highlight=bridgetalk#appname

})(this);