(function(){
  var cs = new CSInterface();
  var currentDir = 'in';

  var effects = [
    {label:'s_shake',        key:'s_shake'},
    {label:'s_blurmocurves', key:'s_blurmocurves'},
    {label:'Twixtor Pro',    key:'twixtor'},
    {label:'Looks',          key:'looks'},
    {label:'BBC Lens Blur',  key:'lensblur'},
    {label:'OBS',            key:'obs'}
  ];

  var quickTools = [
    ['FRZ','freezeFrame()'],    ['FIT','fitToComp()'],       ['ADJ','makeAdjustmentLayer()'],
    ['NUL','makeNull()'],       ['SOL','makeSolid()'],       ['CAM','makeCamera()'],
    ['FILL','applyFill()'],     ['BLUR','applyFastBlur()'],  ['TINT','applyTint()']
  ];

  /* ── helpers ─────────────────────────────────────────────────────── */
  function esc(s){ return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }

  function setStatus(t){ document.getElementById('status').textContent = t || 'Ready'; }

  function runJSX(code, cb){
    setStatus('Working\u2026');
    cs.evalScript(code, function(result){
      if(result && result !== 'undefined') setStatus(result);
      else setStatus('Done');
      if(cb) cb(result);
    });
  }
  window.runJSX = runJSX;

  /* ── resize fix: AE gives the panel 0-width on first render ─────── */
  window.addEventListener('load', function(){
    setTimeout(function(){
      document.body.style.display = 'none';
      void document.body.offsetHeight;
      document.body.style.display = '';
    }, 150);
  });

  /* ── tab switching ───────────────────────────────────────────────── */
  document.querySelectorAll('.tab').forEach(function(btn){
    btn.addEventListener('click', function(){
      document.querySelectorAll('.tab,.panel').forEach(function(el){ el.classList.remove('active'); });
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  /* ── IN / OUT pills ──────────────────────────────────────────────── */
  document.querySelectorAll('.pill').forEach(function(btn){
    btn.addEventListener('click', function(){
      document.querySelectorAll('.pill').forEach(function(el){ el.classList.remove('active'); });
      btn.classList.add('active');
      currentDir = btn.dataset.dir;
    });
  });

  /* ── compact toggle ──────────────────────────────────────────────── */
  document.getElementById('compactBtn').addEventListener('click', function(){
    document.body.classList.toggle('compact');
  });

  /* ── frame slider ────────────────────────────────────────────────── */
  document.getElementById('duration').addEventListener('input', function(){
    document.getElementById('durationValue').textContent = this.value + 'f';
  });

  /* ── FX buttons ──────────────────────────────────────────────────── */
  var effectWrap = document.getElementById('effectButtons');
  effects.forEach(function(f){
    var b = document.createElement('button');
    b.className = 'btn';
    b.textContent = f.label;
    b.addEventListener('click', function(){
      runJSX("applyNamedEffect('" + esc(f.key) + "','" + currentDir + "'," +
             Number(document.getElementById('duration').value) + ")");
    });
    effectWrap.appendChild(b);
  });

  /* ── quick tools ─────────────────────────────────────────────────── */
  var toolWrap = document.getElementById('quickTools');
  quickTools.forEach(function(t){
    var b = document.createElement('button');
    b.className = 'btn';
    b.textContent = t[0];
    b.dataset.jsx = t[1];
    toolWrap.appendChild(b);
  });

  /* ── generic data-jsx handler ────────────────────────────────────── */
  document.querySelectorAll('[data-jsx]').forEach(function(b){
    b.addEventListener('click', function(){ runJSX(b.dataset.jsx); });
  });

  /* ── anchor grid ─────────────────────────────────────────────────── */
  var anchors = [
    ['\u2196',0,0],['\u2191',.5,0],['\u2197',1,0],
    ['\u2190',0,.5],['\u25cf',.5,.5],['\u2192',1,.5],
    ['\u2199',0,1],['\u2193',.5,1],['\u2198',1,1]
  ];
  var aw = document.getElementById('anchorGrid');
  anchors.forEach(function(a){
    var b = document.createElement('button');
    b.className = 'anchor';
    b.textContent = a[0];
    b.addEventListener('click', function(){ runJSX('setAnchor(' + a[1] + ',' + a[2] + ')'); });
    aw.appendChild(b);
  });

  /* ── Precomp: click = all together, alt+click = each separately ──── */
  var precompBtn = document.getElementById('precompBtn');
  if(precompBtn){
    precompBtn.addEventListener('click', function(e){
      runJSX(e.altKey ? 'precomposeEach()' : 'precomposeSelected()');
    });
  }

  /* ── Animation Presets panel ─────────────────────────────────────── */
  (function(){
    var STORAGE_KEY = 'elliePresets_v1';

    function getSaved(){
      try{ return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
      catch(e){ return []; }
    }
    function setSaved(a){
      localStorage.setItem(STORAGE_KEY, JSON.stringify(a));
    }

    function render(){
      var wrap = document.getElementById('presetFileButtons');
      var hint = document.getElementById('presetEmptyHint');
      if(!wrap) return;
      wrap.innerHTML = '';
      var list = getSaved();
      if(hint) hint.style.display = list.length ? 'none' : '';
      list.forEach(function(p){
        var b = document.createElement('button');
        b.className = 'btn';
        b.textContent = p.name;
        b.title = p.path + '\nRight-click to remove';
        b.addEventListener('click', function(){
          runJSX("applyPresetFile('" + esc(p.path) + "')");
        });
        b.addEventListener('contextmenu', function(evt){
          evt.preventDefault();
          setSaved(getSaved().filter(function(x){ return x.path !== p.path; }));
          render();
          setStatus('Removed "' + p.name + '"');
        });
        wrap.appendChild(b);
      });
    }

    // Import
    var importBtn = document.getElementById('importPresetBtn');
    if(importBtn){
      importBtn.addEventListener('click', function(){
        setStatus('Opening file browser\u2026');
        cs.evalScript('browseForPreset()', function(result){
          if(!result || result === '' || result === 'undefined'){
            setStatus('Ready'); return;
          }
          if(result.charAt(0) === '\u26a0'){ setStatus(result); return; }
          var path = result.trim();
          if(!path){ setStatus('Ready'); return; }
          var name = path.replace(/\\/g, '/').split('/').pop().replace(/\.ffx$/i, '');
          var list = getSaved().filter(function(x){ return x.path !== path; });
          list.push({ name: name, path: path });
          setSaved(list);
          render();
          setStatus('Preset "' + name + '" saved \u2014 select layers then click to apply');
        });
      });
    }

    // Clear all
    var clearBtn = document.getElementById('clearPresetsBtn');
    if(clearBtn){
      clearBtn.addEventListener('click', function(){
        setSaved([]);
        render();
        setStatus('All presets cleared.');
      });
    }

    render();
  })();

  /* ── MoBar launcher ──────────────────────────────────────────────── */
  var mobarPanels = [
    {label:'Main',        id:'com.mobar.axwt.main'},
    {label:'Layers',      id:'com.mobar.axwt.layers'},
    {label:'Keyframes',   id:'com.mobar.axwt.keyframes'},
    {label:'Easing',      id:'com.mobar.axwt.easing'},
    {label:'Comp',        id:'com.mobar.axwt.composition'},
    {label:'Expressions', id:'com.mobar.axwt.expressions'}
  ];
  var mobarWrap = document.getElementById('mobarButtons');
  mobarPanels.forEach(function(panel){
    var b = document.createElement('button');
    b.className = 'btn';
    b.textContent = panel.label;
    b.title = 'Open MoBar \u2014 ' + panel.label;
    b.addEventListener('click', function(){
      try{
        cs.requestOpenExtension(panel.id, '');
        setStatus('MoBar ' + panel.label + ' opened');
      } catch(e){
        setStatus('MoBar not installed');
      }
    });
    mobarWrap.appendChild(b);
  });

})();
